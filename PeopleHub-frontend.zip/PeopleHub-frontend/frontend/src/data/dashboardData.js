export const employeeGrowth = [
  { month: "Jan", employees: 120 },
  { month: "Feb", employees: 145 },
  { month: "Mar", employees: 170 },
  { month: "Apr", employees: 195 },
  { month: "May", employees: 220 },
  { month: "Jun", employees: 250 },
];

export const departmentData = [
  { name: "IT", value: 40 },
  { name: "HR", value: 20 },
  { name: "Finance", value: 15 },
  { name: "Sales", value: 25 },
];
