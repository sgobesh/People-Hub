const departments = [
  {
    id: 1,
    name: "Information Technology",
  },
  {
    id: 2,
    name: "Human Resources",
  },
  {
    id: 3,
    name: "Finance",
  },
  {
    id: 4,
    name: "Sales",
  },
  {
    id: 5,
    name: "Marketing",
  },
];

export default departments;
