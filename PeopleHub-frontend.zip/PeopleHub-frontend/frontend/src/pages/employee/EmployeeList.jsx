import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  TextField,
  MenuItem,
  Card,
  CardContent,
  Divider,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";
import TablePagination from "@mui/material/TablePagination";

import PageContainer from "../../components/common/PageContainer";
import PageToolbar from "../../components/common/PageToolbar";
import EmployeeTable from "../../components/tables/EmployeeTable";

import employeeService from "../../services/employeeService";

function EmployeeList() {
  const navigate = useNavigate();

  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState("");

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [totalElements, setTotalElements] = useState(0);


  useEffect(() => {
    loadEmployees();
  }, [page, rowsPerPage]);


  const loadEmployees = async () => {
    try {
      const response = await employeeService.getEmployees(
        page,
        rowsPerPage
      );

      setEmployees(response.data.content);
      setTotalElements(response.data.totalElements);

    } catch (error) {
      console.error(error);
    }
  };


  const handleSearch = async (value) => {
    setSearch(value);

    try {

      if (value.trim() === "") {

        loadEmployees();

      } else {

        const response =
          await employeeService.searchEmployees(value);

        setEmployees(response.data);
        setTotalElements(response.data.length);
        setPage(0);
      }

    } catch (error) {
      console.error(error);
    }
  };


  const handleDelete = (id) => {

    setEmployees((prev) =>
      prev.filter((emp) => emp.id !== id)
    );

    setTotalElements((prev) => prev - 1);
  };


  return (
    <PageContainer>


      {/* Header Toolbar */}

      <Box mb={3}>

        <PageToolbar
          buttonText="+ Add Employee"
          onAdd={() => navigate("/employees/add")}
          search={search}
          onSearch={(e) =>
            handleSearch(e.target.value)
          }
        />

      </Box>



      {/* Filter Section */}

      <Card
        elevation={0}
        sx={{
          mb: 3,
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >

        <CardContent sx={{ p: 3 }}>

          <Typography
            fontWeight={700}
            mb={2}
          >
            Employee Filters
          </Typography>


          <Divider sx={{ mb: 3 }} />


          <Grid
            container
            spacing={3}
          >

            <Grid size={{ xs: 12, md: 6, lg: 3 }}>

              <TextField
                fullWidth
                size="small"
                label="Department"
                select
                defaultValue=""
              >

                <MenuItem value="">
                  All Departments
                </MenuItem>

                <MenuItem value="IT">
                  IT
                </MenuItem>

                <MenuItem value="HR">
                  HR
                </MenuItem>

                <MenuItem value="Finance">
                  Finance
                </MenuItem>

                <MenuItem value="Sales">
                  Sales
                </MenuItem>

              </TextField>

            </Grid>



            <Grid size={{ xs: 12, md: 6, lg: 3 }}>

              <TextField
                fullWidth
                size="small"
                label="Status"
                select
                defaultValue=""
              >

                <MenuItem value="">
                  All Status
                </MenuItem>


                <MenuItem value="Active">
                  Active
                </MenuItem>


                <MenuItem value="Inactive">
                  Inactive
                </MenuItem>


              </TextField>

            </Grid>


          </Grid>


        </CardContent>


      </Card>




      {/* Employee Table */}

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >

        <CardContent sx={{ p: 0 }}>

          <EmployeeTable
            employees={employees}
            onDelete={handleDelete}
          />

        </CardContent>

      </Card>




      {/* Pagination */}

      <Box
        display="flex"
        justifyContent="flex-end"
        mt={2}
      >

        <TablePagination
          component="div"
          count={totalElements}
          page={page}
          rowsPerPage={rowsPerPage}

          onPageChange={(event, newPage) =>
            setPage(newPage)
          }

          onRowsPerPageChange={(event) => {

            setRowsPerPage(
              parseInt(event.target.value, 10)
            );

            setPage(0);

          }}

        />

      </Box>



    </PageContainer>
  );
}


export default EmployeeList;