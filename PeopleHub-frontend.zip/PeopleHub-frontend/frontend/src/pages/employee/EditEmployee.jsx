import { useState, useEffect } from "react";
import departments from "../../data/departments";
import employeeService from "../../services/employeeService";
import { useNavigate, useParams } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  CardContent,
  Divider,
  MenuItem,
  Snackbar,
  Alert,
  TextField,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import SaveIcon from "@mui/icons-material/Save";
import RestartAltIcon from "@mui/icons-material/RestartAlt";

function EditEmployee() {

  const [formData, setFormData] = useState({
    employeeId: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    designation: "",
    salary: "",
    departmentId: "",
  });

  const navigate = useNavigate();
  const { id } = useParams();

  const [errors, setErrors] = useState({});
  const [openSnackbar, setOpenSnackbar] = useState(false);



  const handleChange = (e) => {

    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));

  };



  useEffect(() => {

    loadEmployee();

  }, []);



  const loadEmployee = async () => {

    try {

      const response =
        await employeeService.getEmployeeById(id);

      setFormData(response.data);

    } catch (error) {

      console.error(error);

    }

  };



  const validate = () => {

    let temp = {};

    if (!formData.employeeId.trim())
      temp.employeeId = "Employee ID is required";

    if (!formData.firstName.trim())
      temp.firstName = "First Name is required";

    if (!formData.lastName.trim())
      temp.lastName = "Last Name is required";


    if (!formData.email.trim())
      temp.email = "Email is required";

    else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email)
    )
      temp.email = "Invalid Email";


    if (!formData.phone.trim())
      temp.phone = "Phone Number is required";

    else if (!/^[6-9]\d{9}$/.test(formData.phone))
      temp.phone = "Enter valid mobile number";


    if (!formData.designation.trim())
      temp.designation = "Designation is required";


    if (!formData.salary)
      temp.salary = "Salary is required";


    if (!formData.departmentId)
      temp.departmentId = "Department is required";


    setErrors(temp);

    return Object.keys(temp).length === 0;

  };



  const handleSave = async () => {

    if (!validate())
      return;


    try {

      const employee = {

        employeeId: formData.employeeId,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        designation: formData.designation,
        salary: Number(formData.salary),
        departmentId: Number(formData.departmentId),
        joiningDate: formData.joiningDate,
        gender: formData.gender,

      };


      await employeeService.updateEmployee(id, employee);


      setOpenSnackbar(true);


      setTimeout(() => {

        navigate("/employees");

      }, 1000);



    } catch(error){

      console.error(error);

      alert("Unable to save employee");

    }

  };



  return (

    <PageContainer>


      <PageHeader
        title="Edit Employee"
        subtitle="Update employee profile information."
        breadcrumbs={[
          {
            label:"Dashboard",
            path:"/dashboard"
          },
          {
            label:"Employees",
            path:"/employees"
          },
          {
            label:"Edit Employee"
          }
        ]}
      />



      <Card
        elevation={0}
        sx={{
          maxWidth:1100,
          mx:"auto",
          borderRadius:4,
          border:"1px solid #E5E7EB"
        }}
      >

        <CardContent sx={{p:4}}>


          <Typography
            variant="h5"
            fontWeight={700}
            mb={1}
          >
            Employee Information
          </Typography>


          <Typography
            color="text.secondary"
            mb={3}
          >
            Modify employee details and save changes.
          </Typography>


          <Divider sx={{mb:4}} />



          <Grid
            container
            spacing={3}
          >


            <Grid size={{xs:12,md:6}}>
              <TextField
                fullWidth
                label="First Name"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                error={Boolean(errors.firstName)}
                helperText={errors.firstName}
              />
            </Grid>



            <Grid size={{xs:12,md:6}}>
              <TextField
                fullWidth
                label="Last Name"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                error={Boolean(errors.lastName)}
                helperText={errors.lastName}
              />
            </Grid>



            <Grid size={{xs:12,md:6}}>
              <TextField
                fullWidth
                label="Email Address"
                name="email"
                value={formData.email}
                onChange={handleChange}
                error={Boolean(errors.email)}
                helperText={errors.email}
              />
            </Grid>



            <Grid size={{xs:12,md:6}}>
              <TextField
                fullWidth
                label="Phone Number"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                error={Boolean(errors.phone)}
                helperText={errors.phone}
              />
            </Grid>



            <Grid size={{xs:12,md:6}}>

              <TextField
                fullWidth
                select
                label="Department"
                name="departmentId"
                value={formData.departmentId}
                onChange={handleChange}
                error={Boolean(errors.departmentId)}
                helperText={errors.departmentId}
              >

                {departments.map((dept)=>(

                  <MenuItem
                    key={dept.id}
                    value={dept.id}
                  >
                    {dept.name}
                  </MenuItem>

                ))}

              </TextField>

            </Grid>




            <Grid size={{xs:12,md:6}}>
              <TextField
                fullWidth
                label="Designation"
                name="designation"
                value={formData.designation}
                onChange={handleChange}
                error={Boolean(errors.designation)}
                helperText={errors.designation}
              />
            </Grid>



            <Grid size={{xs:12,md:6}}>
              <TextField
                fullWidth
                type="number"
                label="Salary"
                name="salary"
                value={formData.salary}
                onChange={handleChange}
                error={Boolean(errors.salary)}
                helperText={errors.salary}
              />
            </Grid>



            <Grid size={{xs:12,md:6}}>
              <TextField
                fullWidth
                type="date"
                label="Joining Date"
                name="joiningDate"
                value={formData.joiningDate}
                onChange={handleChange}
                slotProps={{
                  inputLabel:{
                    shrink:true
                  }
                }}
              />
            </Grid>




            <Grid size={{xs:12,md:6}}>
              <TextField
                fullWidth
                select
                label="Gender"
                name="gender"
                value={formData.gender}
                onChange={handleChange}
              >

                <MenuItem value="">
                  Select Gender
                </MenuItem>

                <MenuItem value="Male">
                  Male
                </MenuItem>

                <MenuItem value="Female">
                  Female
                </MenuItem>

                <MenuItem value="Other">
                  Other
                </MenuItem>

              </TextField>

            </Grid>


          </Grid>




          <Divider sx={{my:4}} />



          <Box
            display="flex"
            justifyContent="flex-end"
            gap={2}
          >

            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={()=>navigate("/employees")}
            >
              Cancel
            </Button>


            <Button
              variant="outlined"
              startIcon={<RestartAltIcon />}
              onClick={()=>{
                setErrors({});
              }}
            >
              Reset
            </Button>


            <Button
              variant="contained"
              startIcon={<SaveIcon />}
              onClick={handleSave}
            >
              Update Employee
            </Button>


          </Box>


        </CardContent>

      </Card>



      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={()=>setOpenSnackbar(false)}
        anchorOrigin={{
          vertical:"top",
          horizontal:"right"
        }}
      >

        <Alert
          severity="success"
          variant="filled"
        >
          Employee updated successfully!
        </Alert>

      </Snackbar>


    </PageContainer>

  );
}


export default EditEmployee;