import { useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  CardContent,
  Divider,
  MenuItem,
  Snackbar,
  Alert,
  TextField,
  Typography,
  Avatar,
  Chip,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import PersonAddAlt1RoundedIcon from "@mui/icons-material/PersonAddAlt1Rounded";
import SaveRoundedIcon from "@mui/icons-material/SaveRounded";
import RestartAltRoundedIcon from "@mui/icons-material/RestartAlt";

import departments from "../../data/departments";
import employeeService from "../../services/employeeService";

function AddEmployee() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    designation: "",
    salary: "",
    departmentId: "",
    joiningDate: "",
    gender: "",
  });

  const [errors, setErrors] = useState({});
  const [openSnackbar, setOpenSnackbar] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const validate = () => {
    let temp = {};

    if (!formData.firstName.trim())
      temp.firstName = "First Name is required";

    if (!formData.lastName.trim())
      temp.lastName = "Last Name is required";

    if (!formData.email.trim())
      temp.email = "Email is required";
    else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email)
    )
      temp.email = "Invalid Email Address";

    if (!formData.phone.trim())
      temp.phone = "Phone Number is required";
    else if (!/^[6-9]\d{9}$/.test(formData.phone))
      temp.phone = "Enter valid mobile number";

    if (!formData.designation.trim())
      temp.designation = "Designation is required";

    if (!formData.salary)
      temp.salary = "Salary is required";

    if (!formData.departmentId)
      temp.departmentId = "Department is required";

    if (!formData.joiningDate)
      temp.joiningDate = "Joining Date is required";

    if (!formData.gender)
      temp.gender = "Gender is required";

    setErrors(temp);

    return Object.keys(temp).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;

    try {
      await employeeService.createEmployee({
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        designation: formData.designation,
        salary: Number(formData.salary),
        departmentId: Number(formData.departmentId),
        joiningDate: formData.joiningDate,
        gender: formData.gender,
      });

      setOpenSnackbar(true);

      setTimeout(() => {
        navigate("/employees");
      }, 1000);
    } catch (error) {
      console.error(error);
      alert("Unable to save employee");
    }
  };

  const handleReset = () => {
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      designation: "",
      salary: "",
      departmentId: "",
      joiningDate: "",
      gender: "",
    });

    setErrors({});
  };

  return (
    <Box>

      {/* Header */}

      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={3}
      >
        <Box>
          <Typography
            variant="h4"
            fontWeight={700}
          >
            Add Employee
          </Typography>

          <Typography
            color="text.secondary"
            mt={0.5}
          >
            Create a new employee profile for your organization.
          </Typography>
        </Box>

        <Chip
          color="primary"
          icon={<PersonAddAlt1RoundedIcon />}
          label="New Employee"
          sx={{
            px: 1,
            fontWeight: 600,
          }}
        />
      </Box>

      {/* Main Card */}

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E8ECF3",
        }}
      >
        <CardContent sx={{ p: 4 }}>

          <Box
            display="flex"
            alignItems="center"
            gap={2}
            mb={4}
          >
            <Avatar
              sx={{
                bgcolor: "primary.main",
                width: 55,
                height: 55,
              }}
            >
              <PersonAddAlt1RoundedIcon />
            </Avatar>

            <Box>
              <Typography
                variant="h6"
                fontWeight={700}
              >
                Employee Information
              </Typography>

              <Typography
                variant="body2"
                color="text.secondary"
              >
                Fill all mandatory employee details.
              </Typography>
            </Box>
          </Box>

          <Divider sx={{ mb: 4 }} />

          <Grid container spacing={3}>

            {/* First Name */}

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                label="First Name"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                error={Boolean(errors.firstName)}
                helperText={errors.firstName}
                variant="filled"
              />
            </Grid>

            {/* Last Name */}

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                label="Last Name"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                error={Boolean(errors.lastName)}
                helperText={errors.lastName}
                variant="filled"
              />
            </Grid>

            {/* Email */}

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                label="Email Address"
                name="email"
                value={formData.email}
                onChange={handleChange}
                error={Boolean(errors.email)}
                helperText={errors.email}
                variant="filled"
              />
            </Grid>

            {/* Phone */}

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                label="Mobile Number"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                error={Boolean(errors.phone)}
                helperText={errors.phone}
                inputProps={{ maxLength: 10 }}
                variant="filled"
              />
            </Grid>
                        {/* Department */}

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                select
                fullWidth
                label="Department"
                name="departmentId"
                value={formData.departmentId}
                onChange={handleChange}
                error={Boolean(errors.departmentId)}
                helperText={errors.departmentId}
                variant="filled"
              >
                {departments.map((dept) => (
                  <MenuItem
                    key={dept.id}
                    value={dept.id}
                  >
                    {dept.name}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>

            {/* Designation */}

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                label="Designation"
                name="designation"
                value={formData.designation}
                onChange={handleChange}
                error={Boolean(errors.designation)}
                helperText={errors.designation}
                variant="filled"
              />
            </Grid>

            {/* Salary */}

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                type="number"
                label="Salary"
                name="salary"
                value={formData.salary}
                onChange={handleChange}
                error={Boolean(errors.salary)}
                helperText={errors.salary}
                variant="filled"
              />
            </Grid>

            {/* Joining Date */}

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                type="date"
                label="Joining Date"
                name="joiningDate"
                value={formData.joiningDate}
                onChange={handleChange}
                error={Boolean(errors.joiningDate)}
                helperText={errors.joiningDate}
                variant="filled"
                slotProps={{
                  inputLabel: {
                    shrink: true,
                  },
                }}
              />
            </Grid>

            {/* Gender */}

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                select
                fullWidth
                label="Gender"
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                error={Boolean(errors.gender)}
                helperText={errors.gender}
                variant="filled"
              >
                <MenuItem value="">
                  Select Gender
                </MenuItem>

                <MenuItem value="Male">
                  Male
                </MenuItem>

                <MenuItem value="Female">
                  Female
                </MenuItem>

                <MenuItem value="Other">
                  Other
                </MenuItem>
              </TextField>
            </Grid>

          </Grid>

          <Divider sx={{ mt: 5, mb: 3 }} />

          {/* Action Buttons */}

          <Box
            display="flex"
            justifyContent="flex-end"
            gap={2}
          >
            <Button
              variant="outlined"
              size="large"
              startIcon={<RestartAltRoundedIcon />}
              onClick={handleReset}
              sx={{
                borderRadius: 3,
                px: 4,
              }}
            >
              Reset
            </Button>

            <Button
              variant="contained"
              size="large"
              startIcon={<SaveRoundedIcon />}
              onClick={handleSave}
              sx={{
                borderRadius: 3,
                px: 4,
                boxShadow: "none",
              }}
            >
              Save Employee
            </Button>
          </Box>

        </CardContent>
      </Card>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={() => setOpenSnackbar(false)}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
      >
        <Alert
          severity="success"
          variant="filled"
          onClose={() => setOpenSnackbar(false)}
        >
          Employee added successfully!
        </Alert>
      </Snackbar>

    </Box>
  );
}

export default AddEmployee;