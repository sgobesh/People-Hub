import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import employeeService from "../../services/employeeService";

import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Divider,
  Paper,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import EditIcon from "@mui/icons-material/Edit";

import BadgeIcon from "@mui/icons-material/Badge";
import EmailIcon from "@mui/icons-material/Email";
import PhoneIcon from "@mui/icons-material/Phone";
import BusinessIcon from "@mui/icons-material/Business";
import WorkIcon from "@mui/icons-material/Work";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import WcIcon from "@mui/icons-material/Wc";
import CurrencyRupeeIcon from "@mui/icons-material/CurrencyRupee";

function ViewEmployee() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [employee, setEmployee] = useState(null);

  useEffect(() => {
    loadEmployee();
  }, []);

  const loadEmployee = async () => {
    try {
      const response = await employeeService.getEmployeeById(id);
      setEmployee(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  if (!employee) {
    return (
      <PageContainer>
        <Box
          sx={{
            height: "70vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <CircularProgress size={55} />
        </Box>
      </PageContainer>
    );
  }

  const fullName = `${employee.firstName} ${employee.lastName}`;

  return (
    <PageContainer>

      <PageHeader
        title="Employee Details"
        subtitle="View complete employee profile and information."
        breadcrumbs={[
          { label: "Dashboard", path: "/dashboard" },
          { label: "Employees", path: "/employees" },
          { label: "View Employee" },
        ]}
        actions={
          <>
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/employees")}
            >
              Back
            </Button>

            <Button
              variant="contained"
              startIcon={<EditIcon />}
              onClick={() =>
                navigate(`/employees/edit/${employee.id}`)
              }
            >
              Edit Employee
            </Button>
          </>
        }
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 4 }}>
                  {/* Profile Header */}

          <Box
            sx={{
              display: "flex",
              flexDirection: {
                xs: "column",
                md: "row",
              },
              alignItems: "center",
              gap: 4,
              mb: 5,
            }}
          >
            <Avatar
              sx={{
                width: 110,
                height: 110,
                bgcolor: "primary.main",
                fontSize: 42,
                fontWeight: 700,
              }}
            >
              {employee.firstName?.charAt(0)}
            </Avatar>

            <Box flex={1}>
              <Typography
                variant="h4"
                fontWeight={700}
              >
                {fullName}
              </Typography>

              <Typography
                color="text.secondary"
                mt={1}
              >
                {employee.designation}
              </Typography>

              <Box
                mt={2}
                display="flex"
                gap={2}
                flexWrap="wrap"
              >
                <Chip
                  color="primary"
                  label={employee.departmentName}
                />

                <Chip
                  color="success"
                  icon={<BadgeIcon />}
                  label={employee.employeeId}
                />
              </Box>
            </Box>
          </Box>

          <Divider sx={{ mb: 4 }} />

          <Grid container spacing={3}>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  border: "1px solid #E5E7EB",
                  borderRadius: 3,
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E3F2FD",
                      color: "#1976D2",
                    }}
                  >
                    <EmailIcon />
                  </Avatar>

                  <Box>
                    <Typography
                      color="text.secondary"
                      fontSize={14}
                    >
                      Email Address
                    </Typography>

                    <Typography
                      fontWeight={600}
                    >
                      {employee.email}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  border: "1px solid #E5E7EB",
                  borderRadius: 3,
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#FFF3E0",
                      color: "#FB8C00",
                    }}
                  >
                    <PhoneIcon />
                  </Avatar>

                  <Box>
                    <Typography
                      color="text.secondary"
                      fontSize={14}
                    >
                      Phone Number
                    </Typography>

                    <Typography
                      fontWeight={600}
                    >
                      {employee.phone}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  border: "1px solid #E5E7EB",
                  borderRadius: 3,
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E8F5E9",
                      color: "#2E7D32",
                    }}
                  >
                    <BusinessIcon />
                  </Avatar>

                  <Box>
                    <Typography
                      color="text.secondary"
                      fontSize={14}
                    >
                      Department
                    </Typography>

                    <Typography
                      fontWeight={600}
                    >
                      {employee.departmentName}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  border: "1px solid #E5E7EB",
                  borderRadius: 3,
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#F3E5F5",
                      color: "#8E24AA",
                    }}
                  >
                    <WorkIcon />
                  </Avatar>

                  <Box>
                    <Typography
                      color="text.secondary"
                      fontSize={14}
                    >
                      Designation
                    </Typography>

                    <Typography
                      fontWeight={600}
                    >
                      {employee.designation}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>
                        {/* Joining Date */}

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E8EAF6",
                      color: "#3949AB",
                    }}
                  >
                    <CalendarMonthIcon />
                  </Avatar>

                  <Box>
                    <Typography
                      fontSize={14}
                      color="text.secondary"
                    >
                      Joining Date
                    </Typography>

                    <Typography fontWeight={600}>
                      {employee.joiningDate || "-"}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            {/* Gender */}

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#FCE4EC",
                      color: "#D81B60",
                    }}
                  >
                    <WcIcon />
                  </Avatar>

                  <Box>
                    <Typography
                      fontSize={14}
                      color="text.secondary"
                    >
                      Gender
                    </Typography>

                    <Typography fontWeight={600}>
                      {employee.gender || "-"}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            {/* Salary */}

            <Grid size={{ xs: 12 }}>
              <Paper
                elevation={0}
                sx={{
                  mt: 1,
                  p: 4,
                  borderRadius: 4,
                  background:
                    "linear-gradient(135deg,#1976D2,#42A5F5)",
                  color: "#fff",
                }}
              >
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  flexWrap="wrap"
                >
                  <Box>
                    <Typography
                      sx={{
                        opacity: .9,
                      }}
                    >
                      Annual Salary
                    </Typography>

                    <Typography
                      variant="h3"
                      fontWeight={700}
                      mt={1}
                    >
                      ₹ {Number(employee.salary || 0).toLocaleString("en-IN")}
                    </Typography>
                  </Box>

                  <Avatar
                    sx={{
                      width: 70,
                      height: 70,
                      bgcolor: "rgba(255,255,255,.15)",
                    }}
                  >
                    <CurrencyRupeeIcon
                      sx={{
                        fontSize: 38,
                        color: "#fff",
                      }}
                    />
                  </Avatar>
                </Box>
              </Paper>
            </Grid>

          </Grid>

          <Divider sx={{ my: 4 }} />

          <Box
            display="flex"
            justifyContent="flex-end"
            gap={2}
            flexWrap="wrap"
          >
            <Button
              variant="outlined"
              size="large"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/employees")}
            >
              Back
            </Button>

            <Button
              variant="contained"
              size="large"
              startIcon={<EditIcon />}
              onClick={() =>
                navigate(`/employees/edit/${employee.id}`)
              }
            >
              Edit Employee
            </Button>
          </Box>

        </CardContent>
      </Card>

    </PageContainer>
  );
}

export default ViewEmployee;