import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
} from "@mui/material";

import SaveIcon from "@mui/icons-material/Save";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import JobForm from "../../components/forms/JobForm";
import jobService from "../../services/jobService";

function EditJob() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [formData, setFormData] = useState({
    jobTitle: "",
    department: "",
    description: "",
    experience: "",
    location: "",
    vacancies: "",
    salary: "",
    status: "OPEN",
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    loadJob();
  }, [id]);

  const loadJob = async () => {
    try {
      const response = await jobService.getJobById(id);

      const job = response.data;

      setFormData({
        jobTitle: job.jobTitle || "",
        department: job.department || "",
        description: job.description || "",
        experience: job.experience || "",
        location: job.location || "",
        vacancies: job.vacancies || "",
        salary: job.salary || "",
        status: job.status || "OPEN",
      });
    } catch (error) {
      console.error(error);
      alert("Unable to load job details.");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });

    setErrors({
      ...errors,
      [e.target.name]: "",
    });
  };

  const validate = () => {
    let temp = {};

    if (!formData.jobTitle.trim()) {
      temp.jobTitle = "Job Title is required";
    }

    if (!formData.department.trim()) {
      temp.department = "Department is required";
    }

    if (!formData.location.trim()) {
      temp.location = "Location is required";
    }

    if (!formData.vacancies) {
      temp.vacancies = "Vacancies are required";
    } else if (Number(formData.vacancies) <= 0) {
      temp.vacancies = "Vacancies must be greater than 0";
    }

    if (!formData.salary) {
      temp.salary = "Salary is required";
    } else if (Number(formData.salary) <= 0) {
      temp.salary = "Salary must be greater than 0";
    }

    setErrors(temp);

    return Object.keys(temp).length === 0;
  };

  const updateJob = async () => {
    if (!validate()) return;

    try {
      setSaving(true);

      await jobService.updateJob(id, {
        ...formData,
        vacancies: Number(formData.vacancies),
        salary: Number(formData.salary),
      });

      alert("Job Updated Successfully");

      navigate(`/jobs/view/${id}`);
    } catch (error) {
      console.error(error);

      alert(
        error.response?.data?.message ||
          "Unable to update job."
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <PageContainer>
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          minHeight="60vh"
        >
          <CircularProgress />
        </Box>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Edit Job"
        subtitle="Update job details."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Jobs",
            path: "/jobs",
          },
          {
            label: "Edit Job",
          },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          maxWidth: 1000,
          mx: "auto",
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <JobForm
            formData={formData}
            handleChange={handleChange}
            errors={errors}
          />

          <Box
            display="flex"
            justifyContent="flex-end"
            gap={2}
            mt={4}
          >
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/jobs")}
            >
              Cancel
            </Button>

            <Button
              variant="contained"
              startIcon={<SaveIcon />}
              onClick={updateJob}
              disabled={saving}
            >
              {saving ? "Updating..." : "Update Job"}
            </Button>
          </Box>
        </CardContent>
      </Card>
    </PageContainer>
  );
}

export default EditJob;