import { useEffect, useMemo, useState } from "react";
import {
  Box,
  Card,
  CardContent,
  Divider,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";
import TablePagination from "@mui/material/TablePagination";

import { useNavigate } from "react-router-dom";

import PageContainer from "../../components/common/PageContainer";
import PageToolbar from "../../components/common/PageToolbar";

import CandidateTable from "../../components/tables/CandidateTable";
import candidateService from "../../services/candidateService";

function CandidateList() {
  const navigate = useNavigate();

  const [candidates, setCandidates] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  useEffect(() => {
    loadCandidates();
  }, []);

  const loadCandidates = async () => {
    try {
      const response = await candidateService.getAllCandidates();
      setCandidates(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this candidate?")) return;

    try {
      await candidateService.deleteCandidate(id);

      alert("Candidate deleted successfully.");

      loadCandidates();
    } catch (error) {
      console.error(error);
      alert("Unable to delete candidate.");
    }
  };

  const filteredCandidates = useMemo(() => {
    let data = [...candidates];

    if (search.trim()) {
      const keyword = search.toLowerCase();

      data = data.filter((candidate) => {
        const fullName =
          `${candidate.firstName ?? ""} ${candidate.lastName ?? ""}`.toLowerCase();

        return (
          fullName.includes(keyword) ||
          candidate.email?.toLowerCase().includes(keyword) ||
          candidate.phone?.includes(keyword)
        );
      });
    }

    if (statusFilter !== "ALL") {
      data = data.filter(
        (candidate) => candidate.status === statusFilter
      );
    }

    return data;
  }, [candidates, search, statusFilter]);

  return (
    <PageContainer>

      {/* Header */}

      <Box mb={3}>
        <PageToolbar
          buttonText="+ Add Candidate"
          onAdd={() => navigate("/candidates/add")}
          search={search}
          onSearch={(e) => setSearch(e.target.value)}
        />
      </Box>

      {/* Filter Card */}

      <Card
        elevation={0}
        sx={{
          mb: 3,
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 3 }}>
          <Typography
            fontWeight={700}
            mb={2}
          >
            Candidate Filters
          </Typography>

          <Divider sx={{ mb: 3 }} />

          <Grid container spacing={3}>
            <Grid size={{ xs: 12, md: 6, lg: 3 }}>
              <TextField
                fullWidth
                size="small"
                select
                label="Status"
                value={statusFilter}
                onChange={(e) =>
                  setStatusFilter(e.target.value)
                }
              >
                <MenuItem value="ALL">All Status</MenuItem>
                <MenuItem value="APPLIED">Applied</MenuItem>
                <MenuItem value="SHORTLISTED">
                  Shortlisted
                </MenuItem>
                <MenuItem value="SELECTED">
                  Selected
                </MenuItem>
                <MenuItem value="REJECTED">
                  Rejected
                </MenuItem>
              </TextField>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Table */}

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 0 }}>
          <CandidateTable
            candidates={filteredCandidates.slice(
              page * rowsPerPage,
              page * rowsPerPage + rowsPerPage
            )}
            page={page}
            rowsPerPage={rowsPerPage}
            setPage={setPage}
            setRowsPerPage={setRowsPerPage}
            loadCandidates={loadCandidates}
            onDelete={handleDelete}
          />
        </CardContent>
      </Card>

      {/* Pagination */}

      <Box
        display="flex"
        justifyContent="flex-end"
        mt={2}
      >
        <TablePagination
          component="div"
          count={filteredCandidates.length}
          page={page}
          rowsPerPage={rowsPerPage}
          onPageChange={(event, newPage) =>
            setPage(newPage)
          }
          onRowsPerPageChange={(event) => {
            setRowsPerPage(
              parseInt(event.target.value, 10)
            );
            setPage(0);
          }}
        />
      </Box>

    </PageContainer>
  );
}

export default CandidateList;