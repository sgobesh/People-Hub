import { useEffect, useState } from "react";
import {
  Box,
  Card,
  CardContent,
  CircularProgress,
  Divider,
  List,
  ListItem,
  ListItemText,
  Typography,
  Chip,
} from "@mui/material";
import Grid from "@mui/material/Grid";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import jobService from "../../services/jobService";
import candidateService from "../../services/candidateService";

function DashboardCard({
  title,
  value,
  color = "primary.main",
}) {
  return (
    <Card
      elevation={0}
      sx={{
        borderRadius: 3,
        border: "1px solid #E5E7EB",
        height: "100%",
      }}
    >
      <CardContent>
        <Typography
          variant="body2"
          color="text.secondary"
          gutterBottom
        >
          {title}
        </Typography>

        <Typography
          variant="h4"
          fontWeight={700}
          color={color}
        >
          {value}
        </Typography>
      </CardContent>
    </Card>
  );
}

export default function RecruitmentDashboard() {
  const [jobs, setJobs] = useState([]);
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const [jobResponse, candidateResponse] =
        await Promise.all([
          jobService.getAllJobs(),
          candidateService.getAllCandidates(),
        ]);

      setJobs(jobResponse.data);
      setCandidates(candidateResponse.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <PageContainer>
        <Box
          display="flex"
          justifyContent="center"
          mt={8}
        >
          <CircularProgress />
        </Box>
      </PageContainer>
    );
  }

  const totalJobs = jobs.length;
  const openJobs = jobs.filter(
    (job) => job.status === "OPEN"
  ).length;
  const closedJobs = jobs.filter(
    (job) => job.status === "CLOSED"
  ).length;

  const totalCandidates = candidates.length;
  const applied = candidates.filter(
    (candidate) => candidate.status === "APPLIED"
  ).length;
  const shortlisted = candidates.filter(
    (candidate) => candidate.status === "SHORTLISTED"
  ).length;
  const selected = candidates.filter(
    (candidate) => candidate.status === "SELECTED"
  ).length;
  const rejected = candidates.filter(
    (candidate) => candidate.status === "REJECTED"
  ).length;

  return (
    <PageContainer>
      <PageHeader
        title="Recruitment Dashboard"
        subtitle="Monitor job openings and candidate progress."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Recruitment Dashboard",
          },
        ]}
      />

      {/* Statistics */}
      <Grid container spacing={3} mb={4}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <DashboardCard
            title="Total Jobs"
            value={totalJobs}
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <DashboardCard
            title="Open Jobs"
            value={openJobs}
            color="success.main"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <DashboardCard
            title="Closed Jobs"
            value={closedJobs}
            color="error.main"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <DashboardCard
            title="Candidates"
            value={totalCandidates}
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <DashboardCard
            title="Applied"
            value={applied}
            color="info.main"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <DashboardCard
            title="Shortlisted"
            value={shortlisted}
            color="warning.main"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <DashboardCard
            title="Selected"
            value={selected}
            color="success.main"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <DashboardCard
            title="Rejected"
            value={rejected}
            color="error.main"
          />
        </Grid>
      </Grid>

      {/* Recent Data */}
      <Grid container spacing={3}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Card
            elevation={0}
            sx={{
              borderRadius: 3,
              border: "1px solid #E5E7EB",
            }}
          >
            <CardContent>
              <Typography
                variant="h6"
                fontWeight={700}
              >
                Recent Jobs
              </Typography>

              <Divider sx={{ my: 2 }} />

              <List disablePadding>
                {jobs.slice(0, 5).map((job) => (
                  <ListItem
                    key={job.id}
                    divider
                    secondaryAction={
                      <Chip
                        label={job.status}
                        color={
                          job.status === "OPEN"
                            ? "success"
                            : "error"
                        }
                        size="small"
                      />
                    }
                  >
                    <ListItemText
                      primary={job.jobTitle}
                      secondary={`${job.department} • ${job.location}`}
                    />
                  </ListItem>
                ))}

                {jobs.length === 0 && (
                  <Typography
                    align="center"
                    color="text.secondary"
                    py={2}
                  >
                    No Jobs Available
                  </Typography>
                )}
              </List>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <Card
            elevation={0}
            sx={{
              borderRadius: 3,
              border: "1px solid #E5E7EB",
            }}
          >
            <CardContent>
              <Typography
                variant="h6"
                fontWeight={700}
              >
                Recent Candidates
              </Typography>

              <Divider sx={{ my: 2 }} />

              <List disablePadding>
                {candidates.slice(0, 5).map((candidate) => (
                  <ListItem
                    key={candidate.id}
                    divider
                    secondaryAction={
                      <Chip
                        label={candidate.status}
                        color={
                          candidate.status === "SELECTED"
                            ? "success"
                            : candidate.status === "SHORTLISTED"
                            ? "warning"
                            : candidate.status === "REJECTED"
                            ? "error"
                            : "info"
                        }
                        size="small"
                      />
                    }
                  >
                    <ListItemText
                      primary={`${candidate.firstName} ${candidate.lastName}`}
                      secondary={candidate.jobTitle}
                    />
                  </ListItem>
                ))}

                {candidates.length === 0 && (
                  <Typography
                    align="center"
                    color="text.secondary"
                    py={2}
                  >
                    No Candidates Available
                  </Typography>
                )}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </PageContainer>
  );
}