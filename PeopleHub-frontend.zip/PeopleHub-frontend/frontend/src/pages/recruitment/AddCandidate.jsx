import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import SaveIcon from "@mui/icons-material/Save";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

import CandidateForm from "../../components/forms/CandidateForm";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import candidateService from "../../services/candidateService";
import jobService from "../../services/jobService";

function AddCandidate() {
  const navigate = useNavigate();

  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    experience: "",
    qualification: "",
    skills: "",
    resumeUrl: "",
    jobId: "",
    status: "APPLIED",
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    loadJobs();
  }, []);

  const loadJobs = async () => {
    try {
      const response = await jobService.getAllJobs();
      setJobs(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const validate = () => {
    let temp = {};

    if (!formData.firstName.trim())
      temp.firstName = "First Name is required";

    if (!formData.lastName.trim())
      temp.lastName = "Last Name is required";

    if (!formData.email.trim()) {
      temp.email = "Email is required";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email)
    ) {
      temp.email = "Enter a valid email address";
    }

    if (!formData.phone) {
      temp.phone = "Mobile Number is required";
    } else if (!/^[6-9]\d{9}$/.test(formData.phone)) {
      temp.phone = "Mobile Number must be exactly 10 digits";
    }

    if (!formData.jobId)
      temp.jobId = "Please select a Job";

    if (!formData.qualification.trim())
      temp.qualification = "Qualification is required";

    if (!formData.experience)
      temp.experience = "Experience is required";

    setErrors(temp);

    return Object.keys(temp).length === 0;
  };

  const saveCandidate = async () => {
    if (!validate()) return;

    try {
      setLoading(true);

      const response = await candidateService.createCandidate({
        ...formData,
        jobId: Number(formData.jobId),
      });

      alert("Candidate Added Successfully");

      navigate(`/candidates/view/${response.data.id}`);
    } catch (error) {
      console.error(error);

      if (error.response) {
        alert(error.response.data.message || "Unable to save candidate.");
      } else {
        alert("Something went wrong.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageContainer>
      <PageHeader
        title="Add Candidate"
        subtitle="Register a new candidate for recruitment."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Candidates",
            path: "/candidates",
          },
          {
            label: "Add Candidate",
          },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          maxWidth: 1000,
          mx: "auto",
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 4 }}>
          {loading ? (
            <Box
              display="flex"
              justifyContent="center"
              py={6}
            >
              <CircularProgress />
            </Box>
          ) : (
            <>
              <CandidateForm
                formData={formData}
                handleChange={handleChange}
                errors={errors}
                jobs={jobs}
              />

              <Grid
                container
                justifyContent="flex-end"
                spacing={2}
                mt={2}
              >
                <Grid>
                  <Button
                    variant="outlined"
                    startIcon={<ArrowBackIcon />}
                    onClick={() => navigate("/candidates")}
                  >
                    Cancel
                  </Button>
                </Grid>

                <Grid>
                  <Button
                    variant="contained"
                    startIcon={<SaveIcon />}
                    onClick={saveCandidate}
                    disabled={loading}
                  >
                    Save Candidate
                  </Button>
                </Grid>
              </Grid>
            </>
          )}
        </CardContent>
      </Card>
    </PageContainer>
  );
}

export default AddCandidate;