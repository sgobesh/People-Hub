import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
} from "@mui/material";

import SaveIcon from "@mui/icons-material/Save";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import CandidateForm from "../../components/forms/CandidateForm";

import candidateService from "../../services/candidateService";
import jobService from "../../services/jobService";

function EditCandidate() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    experience: "",
    qualification: "",
    skills: "",
    resumeUrl: "",
    jobId: "",
    status: "APPLIED",
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    loadCandidate();
    loadJobs();
  }, []);

  const loadCandidate = async () => {
    try {
      const response = await candidateService.getCandidateById(id);

      const candidate = response.data;

      setFormData({
        firstName: candidate.firstName || "",
        lastName: candidate.lastName || "",
        email: candidate.email || "",
        phone: candidate.phone || "",
        experience: candidate.experience || "",
        qualification: candidate.qualification || "",
        skills: candidate.skills || "",
        resumeUrl: candidate.resumeUrl || "",
        jobId:
          candidate.jobId ||
          candidate.job?.id ||
          "",
        status: candidate.status || "APPLIED",
      });
    } catch (error) {
      console.error(error);
      alert("Unable to load candidate details.");
    } finally {
      setLoading(false);
    }
  };

  const loadJobs = async () => {
    try {
      const response = await jobService.getAllJobs();

      if (response.data.content) {
        setJobs(response.data.content);
      } else {
        setJobs(response.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });

    setErrors({
      ...errors,
      [e.target.name]: "",
    });
  };

  const validate = () => {
    let temp = {};

    if (!formData.firstName.trim()) {
      temp.firstName = "First Name is required";
    }

    if (!formData.lastName.trim()) {
      temp.lastName = "Last Name is required";
    }

    if (!formData.email.trim()) {
      temp.email = "Email is required";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(
        formData.email
      )
    ) {
      temp.email = "Enter a valid email";
    }

    if (!formData.phone.trim()) {
      temp.phone = "Mobile Number is required";
    } else if (!/^[6-9]\d{9}$/.test(formData.phone)) {
      temp.phone = "Mobile Number must be 10 digits";
    }

    if (!formData.jobId) {
      temp.jobId = "Please select a Job";
    }

    setErrors(temp);

    return Object.keys(temp).length === 0;
  };

  const updateCandidate = async () => {
    if (!validate()) return;

    try {
      setSaving(true);

      await candidateService.updateCandidate(id, {
        ...formData,
        jobId: Number(formData.jobId),
      });

      alert("Candidate Updated Successfully");

      navigate(`/candidates/view/${id}`);
    } catch (error) {
      console.error(error);

      alert(
        error.response?.data?.message ||
          "Unable to update candidate."
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <PageContainer>
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          minHeight="60vh"
        >
          <CircularProgress />
        </Box>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Edit Candidate"
        subtitle="Update candidate information."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Candidates",
            path: "/candidates",
          },
          {
            label: "Edit Candidate",
          },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          maxWidth: 1000,
          mx: "auto",
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <CandidateForm
            formData={formData}
            handleChange={handleChange}
            errors={errors}
            jobs={jobs}
          />

          <Box
            display="flex"
            justifyContent="flex-end"
            gap={2}
            mt={4}
          >
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/candidates")}
            >
              Cancel
            </Button>

            <Button
              variant="contained"
              startIcon={<SaveIcon />}
              onClick={updateCandidate}
              disabled={saving}
            >
              {saving
                ? "Updating..."
                : "Update Candidate"}
            </Button>
          </Box>
        </CardContent>
      </Card>
    </PageContainer>
  );
}

export default EditCandidate;