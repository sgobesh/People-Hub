import { useState } from "react";
import { Box, Button, Card, CardContent } from "@mui/material";
import SaveIcon from "@mui/icons-material/Save";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from "react-router-dom";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import JobForm from "../../components/forms/JobForm";
import jobService from "../../services/jobService";

function AddJob() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    jobTitle: "",
    department: "",
    description: "",
    location: "",
    vacancies: "",
    salary: "",
    status: "OPEN",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const validate = () => {
    let temp = {};

    if (!formData.jobTitle.trim())
      temp.jobTitle = "Job Title is required";

    if (!formData.department.trim())
      temp.department = "Department is required";

    if (!formData.location.trim())
      temp.location = "Location is required";

    if (!formData.vacancies)
      temp.vacancies = "Vacancies are required";

    if (!formData.salary)
      temp.salary = "Salary is required";

    setErrors(temp);

    return Object.keys(temp).length === 0;
  };

  const saveJob = async () => {
    if (!validate()) return;

    try {
      setLoading(true);

      const response = await jobService.createJob({
        ...formData,
        vacancies: Number(formData.vacancies),
        salary: Number(formData.salary),
      });

      alert("Job Created Successfully");

      navigate(`/jobs/view/${response.data.id}`);
    } catch (error) {
      console.error(error);
      alert(error.response?.data?.message || "Unable to create job.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageContainer>
      <PageHeader
        title="Add Job"
        subtitle="Create a new job opening."
        breadcrumbs={[
          { label: "Dashboard", path: "/dashboard" },
          { label: "Jobs", path: "/jobs" },
          { label: "Add Job" },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          maxWidth: 900,
          mx: "auto",
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <JobForm
            formData={formData}
            handleChange={handleChange}
            errors={errors}
          />

          <Box display="flex" justifyContent="flex-end" gap={2} mt={4}>
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/jobs")}
            >
              Cancel
            </Button>

            <Button
              variant="contained"
              startIcon={<SaveIcon />}
              disabled={loading}
              onClick={saveJob}
            >
              {loading ? "Saving..." : "Save Job"}
            </Button>
          </Box>
        </CardContent>
      </Card>
    </PageContainer>
  );
}

export default AddJob;