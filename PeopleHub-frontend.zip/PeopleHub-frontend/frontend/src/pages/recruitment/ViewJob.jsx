import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import jobService from "../../services/jobService";

import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Divider,
  Paper,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import EditIcon from "@mui/icons-material/Edit";
import WorkIcon from "@mui/icons-material/Work";
import BusinessCenterIcon from "@mui/icons-material/BusinessCenter";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import PeopleIcon from "@mui/icons-material/People";
import CurrencyRupeeIcon from "@mui/icons-material/CurrencyRupee";
import DescriptionIcon from "@mui/icons-material/Description";

function ViewJob() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [job, setJob] = useState(null);

  useEffect(() => {
    loadJob();
  }, [id]);

  const loadJob = async () => {
    try {
      const response = await jobService.getJobById(id);
      setJob(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  if (!job) {
    return (
      <PageContainer>
        <Box
          sx={{
            height: "70vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <CircularProgress size={55} />
        </Box>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Job Details"
        subtitle="View complete job information."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Jobs",
            path: "/jobs",
          },
          {
            label: "View Job",
          },
        ]}
        actions={
          <>
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/jobs")}
            >
              Back
            </Button>

            <Button
              variant="contained"
              startIcon={<EditIcon />}
              onClick={() => navigate(`/jobs/edit/${job.id}`)}
            >
              Edit Job
            </Button>
          </>
        }
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 4 }}>
          {/* Header */}

          <Box
            sx={{
              display: "flex",
              flexDirection: {
                xs: "column",
                md: "row",
              },
              alignItems: "center",
              gap: 4,
              mb: 5,
            }}
          >
            <Avatar
              sx={{
                width: 110,
                height: 110,
                bgcolor: "primary.main",
                fontSize: 42,
                fontWeight: 700,
              }}
            >
              <WorkIcon fontSize="large" />
            </Avatar>

            <Box flex={1}>
              <Typography variant="h4" fontWeight={700}>
                {job.jobTitle}
              </Typography>

              <Typography color="text.secondary" mt={1}>
                Recruitment Job Information
              </Typography>

              <Box mt={2} display="flex" gap={2} flexWrap="wrap">
                

                <Chip
                  label={job.status}
                  color={job.status === "OPEN" ? "success" : "error"}
                />
              </Box>
            </Box>
          </Box>

          <Divider sx={{ mb: 4 }} />

          <Grid container spacing={3}>
            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E3F2FD",
                      color: "#1976D2",
                    }}
                  >
                    <BusinessCenterIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Department
                    </Typography>

                    <Typography fontWeight={600}>
                      {job.department}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#FFF3E0",
                      color: "#FB8C00",
                    }}
                  >
                    <LocationOnIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Location
                    </Typography>

                    <Typography fontWeight={600}>
                      {job.location}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E8F5E9",
                      color: "#2E7D32",
                    }}
                  >
                    <PeopleIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Vacancies
                    </Typography>

                    <Typography fontWeight={600}>
                      {job.vacancies}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#F3E5F5",
                      color: "#8E24AA",
                    }}
                  >
                    <CurrencyRupeeIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Salary
                    </Typography>

                    <Typography fontWeight={600}>
                      ₹ {job.salary?.toLocaleString()}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E3F2FD",
                      color: "#1976D2",
                    }}
                  >
                    <DescriptionIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Job Description
                    </Typography>

                    <Typography sx={{ mt: 1 }} fontWeight={500}>
                      {job.description || "-"}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>
          </Grid>

          <Divider sx={{ my: 4 }} />

          <Box
            display="flex"
            justifyContent="flex-end"
            gap={2}
            flexWrap="wrap"
          >
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/jobs")}
            >
              Back
            </Button>

            <Button
              variant="contained"
              startIcon={<EditIcon />}
              onClick={() => navigate(`/jobs/edit/${job.id}`)}
            >
              Edit Job
            </Button>
          </Box>
        </CardContent>
      </Card>
    </PageContainer>
  );
}

export default ViewJob;