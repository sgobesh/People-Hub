import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import candidateService from "../../services/candidateService";

import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Divider,
  Paper,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import EditIcon from "@mui/icons-material/Edit";
import PersonIcon from "@mui/icons-material/Person";
import EmailIcon from "@mui/icons-material/Email";
import PhoneIcon from "@mui/icons-material/Phone";
import SchoolIcon from "@mui/icons-material/School";
import WorkIcon from "@mui/icons-material/Work";
import BusinessCenterIcon from "@mui/icons-material/BusinessCenter";
import PsychologyIcon from "@mui/icons-material/Psychology";
import DescriptionIcon from "@mui/icons-material/Description";

function ViewCandidate() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [candidate, setCandidate] = useState(null);

  useEffect(() => {
    loadCandidate();
  }, []);

  const loadCandidate = async () => {
    try {
      const response = await candidateService.getCandidateById(id);
      setCandidate(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "SELECTED":
        return "success";
      case "SHORTLISTED":
        return "warning";
      case "REJECTED":
        return "error";
      default:
        return "info";
    }
  };

  if (!candidate) {
    return (
      <PageContainer>
        <Box
          sx={{
            height: "70vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <CircularProgress size={55} />
        </Box>
      </PageContainer>
    );
  }

  return (
    <PageContainer>

      <PageHeader
        title="Candidate Details"
        subtitle="View complete candidate information."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Candidates",
            path: "/candidates",
          },
          {
            label: "View Candidate",
          },
        ]}
        actions={
          <>
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/candidates")}
            >
              Back
            </Button>

            <Button
              variant="contained"
              startIcon={<EditIcon />}
              onClick={() =>
                navigate(`/candidates/edit/${candidate.id}`)
              }
            >
              Edit Candidate
            </Button>
          </>
        }
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 4 }}>

          {/* Profile Header */}

          <Box
            sx={{
              display: "flex",
              flexDirection: {
                xs: "column",
                md: "row",
              },
              alignItems: "center",
              gap: 4,
              mb: 5,
            }}
          >
            <Avatar
              sx={{
                width: 110,
                height: 110,
                bgcolor: "primary.main",
                fontSize: 40,
                fontWeight: 700,
              }}
            >
              {candidate.firstName?.charAt(0)}
            </Avatar>

            <Box flex={1}>
              <Typography
                variant="h4"
                fontWeight={700}
              >
                {candidate.firstName} {candidate.lastName}
              </Typography>

              <Typography
                color="text.secondary"
                mt={1}
              >
                Candidate Profile
              </Typography>

              <Box
                mt={2}
                display="flex"
                gap={2}
                flexWrap="wrap"
              >
                

                <Chip
                  label={candidate.status}
                  color={getStatusColor(candidate.status)}
                />
              </Box>
            </Box>
          </Box>

          <Divider sx={{ mb: 4 }} />

          <Grid container spacing={3}>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E8F5E9",
                      color: "#2E7D32",
                    }}
                  >
                    <EmailIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Email
                    </Typography>

                    <Typography fontWeight={600}>
                      {candidate.email}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#FFF3E0",
                      color: "#FB8C00",
                    }}
                  >
                    <PhoneIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Mobile
                    </Typography>

                    <Typography fontWeight={600}>
                      {candidate.phone || "-"}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E3F2FD",
                      color: "#1976D2",
                    }}
                  >
                    <WorkIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Experience
                    </Typography>

                    <Typography fontWeight={600}>
                      {candidate.experience || "-"} Years
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#F3E5F5",
                      color: "#8E24AA",
                    }}
                  >
                    <SchoolIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Qualification
                    </Typography>

                    <Typography fontWeight={600}>
                      {candidate.qualification || "-"}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#FFF8E1",
                      color: "#F9A825",
                    }}
                  >
                    <BusinessCenterIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Applied Job
                    </Typography>

                    <Typography fontWeight={600}>
                      {candidate.jobTitle || "-"}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E8EAF6",
                      color: "#3949AB",
                    }}
                  >
                    <PsychologyIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Skills
                    </Typography>

                    <Typography fontWeight={600}>
                      {candidate.skills || "-"}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E3F2FD",
                      color: "#1976D2",
                    }}
                  >
                    <DescriptionIcon />
                  </Avatar>

                  <Box>
                    <Typography fontSize={14} color="text.secondary">
                      Resume URL
                    </Typography>

                    <Typography fontWeight={500} sx={{ mt: 1 }}>
                      {candidate.resumeUrl || "-"}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

          </Grid>

          <Divider sx={{ my: 4 }} />

          <Box
            display="flex"
            justifyContent="flex-end"
            gap={2}
          >
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/candidates")}
            >
              Back
            </Button>

            <Button
              variant="contained"
              startIcon={<EditIcon />}
              onClick={() =>
                navigate(`/candidates/edit/${candidate.id}`)
              }
            >
              Edit Candidate
            </Button>
          </Box>

        </CardContent>
      </Card>

    </PageContainer>
  );
}

export default ViewCandidate;