import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Alert,
  Box,
  Card,
  CardContent,
  Snackbar,
} from "@mui/material";

import PageContainer from "../../components/common/PageContainer";
import PageToolbar from "../../components/common/PageToolbar";

import JobTable from "../../components/tables/JobTable";
import jobService from "../../services/jobService";

function JobList() {
  const navigate = useNavigate();

  const [jobs, setJobs] = useState([]);
  const [search, setSearch] = useState("");

  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    loadJobs();
  }, []);

  const loadJobs = async () => {
    try {
      const response = await jobService.getAllJobs();
      setJobs(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSearch = (value) => {
    setSearch(value);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this job?")) return;

    try {
      await jobService.deleteJob(id);

      setMessage("Job deleted successfully");
      setOpenSnackbar(true);

      loadJobs();
    } catch (error) {
      console.error(error);
    }
  };

  const filteredJobs = jobs.filter((job) => {
    const keyword = search.toLowerCase();

    return (
      job.jobTitle?.toLowerCase().includes(keyword) ||
      job.department?.toLowerCase().includes(keyword) ||
      job.location?.toLowerCase().includes(keyword) ||
      job.status?.toLowerCase().includes(keyword)
    );
  });

  return (
    <PageContainer>
      <Box mb={3}>
        <PageToolbar
          buttonText="+ Add Job"
          onAdd={() => navigate("/jobs/add")}
          search={search}
          onSearch={(e) => handleSearch(e.target.value)}
        />
      </Box>

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 0 }}>
          <JobTable
            jobs={filteredJobs}
            loadJobs={loadJobs}
            onDelete={handleDelete}
          />
        </CardContent>
      </Card>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={() => setOpenSnackbar(false)}
      >
        <Alert
          severity="success"
          variant="filled"
          onClose={() => setOpenSnackbar(false)}
        >
          {message}
        </Alert>
      </Snackbar>
    </PageContainer>
  );
}

export default JobList;