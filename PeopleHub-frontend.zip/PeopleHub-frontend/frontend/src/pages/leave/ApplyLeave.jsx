import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Grid,
  MenuItem,
  Snackbar,
  TextField,
  Typography,
} from "@mui/material";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import leaveService from "../../services/leaveService";
import employeeService from "../../services/employeeService";

function ApplyLeave() {
  const navigate = useNavigate();

  const [employees, setEmployees] = useState([]);

  const [formData, setFormData] = useState({
    employeeId: "",
    leaveType: "",
    startDate: "",
    endDate: "",
    reason: "",
    remarks: "",
  });

  const [errors, setErrors] = useState({});
  const [openSnackbar, setOpenSnackbar] = useState(false);

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    try {
      const response = await employeeService.getAllEmployees();

      if (response.data.content) {
        setEmployees(response.data.content);
      } else {
        setEmployees(response.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const validate = () => {
    let temp = {};

    if (!formData.employeeId)
      temp.employeeId = "Employee is required";

    if (!formData.leaveType)
      temp.leaveType = "Leave Type is required";

    if (!formData.startDate)
      temp.startDate = "Start Date is required";

    if (!formData.endDate)
      temp.endDate = "End Date is required";

    if (
      formData.startDate &&
      formData.endDate &&
      formData.endDate < formData.startDate
    ) {
      temp.endDate =
        "End Date cannot be before Start Date";
    }

    if (!formData.reason.trim())
      temp.reason = "Reason is required";

    setErrors(temp);

    return Object.keys(temp).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) return;

    try {
      const payload = {
        employeeId: Number(formData.employeeId),
        leaveType: formData.leaveType,
        startDate: formData.startDate,
        endDate: formData.endDate,
        reason: formData.reason,
        remarks: formData.remarks,
      };

      await leaveService.addLeave(payload);

      setOpenSnackbar(true);

      setTimeout(() => {
        navigate("/leave");
      }, 1200);

    } catch (error) {
      console.error(error);

      alert(
        error.response?.data?.message ||
        "Unable to apply leave."
      );
    }
  };
    return (
    <PageContainer>

      <PageHeader
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Leave",
            path: "/leave",
          },
          {
            label: "Apply Leave",
          },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 4 }}>

          <Typography
            variant="h5"
            fontWeight="bold"
            mb={3}
          >
            Apply Leave
          </Typography>

          <Box
            component="form"
            onSubmit={handleSubmit}
          >

            <Grid container spacing={3}>

              {/* Employee */}

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  select
                  label="Employee"
                  name="employeeId"
                  value={formData.employeeId}
                  onChange={handleChange}
                  error={Boolean(errors.employeeId)}
                  helperText={errors.employeeId}
                >
                  <MenuItem value="">
                    Select Employee
                  </MenuItem>

                  {employees.map((emp) => (
                    <MenuItem
                      key={emp.id}
                      value={emp.id}
                    >
                      {emp.firstName} {emp.lastName}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>

              {/* Leave Type */}

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  select
                  label="Leave Type"
                  name="leaveType"
                  value={formData.leaveType}
                  onChange={handleChange}
                  error={Boolean(errors.leaveType)}
                  helperText={errors.leaveType}
                >
                  <MenuItem value="">
                    Select Leave Type
                  </MenuItem>

                  <MenuItem value="Casual">
                    Casual Leave
                  </MenuItem>

                  <MenuItem value="Sick">
                    Sick Leave
                  </MenuItem>

                  <MenuItem value="Paid">
                    Paid Leave
                  </MenuItem>

                  <MenuItem value="Loss Of Pay">
                    Loss Of Pay
                  </MenuItem>
                </TextField>
              </Grid>

              {/* Start Date */}

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  type="date"
                  label="Start Date"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleChange}
                  error={Boolean(errors.startDate)}
                  helperText={errors.startDate}
                  slotProps={{
                    inputLabel: {
                      shrink: true,
                    },
                  }}
                />
              </Grid>

              {/* End Date */}

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  type="date"
                  label="End Date"
                  name="endDate"
                  value={formData.endDate}
                  onChange={handleChange}
                  error={Boolean(errors.endDate)}
                  helperText={errors.endDate}
                  slotProps={{
                    inputLabel: {
                      shrink: true,
                    },
                  }}
                />
              </Grid>

              {/* Reason */}

              <Grid size={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={4}
                  label="Reason"
                  name="reason"
                  value={formData.reason}
                  onChange={handleChange}
                  error={Boolean(errors.reason)}
                  helperText={errors.reason}
                />
              </Grid>

              {/* Remarks */}

              <Grid size={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={3}
                  label="Remarks"
                  name="remarks"
                  value={formData.remarks}
                  onChange={handleChange}
                />
              </Grid>

            </Grid>

            <Box
              sx={{
                mt: 4,
                pt: 3,
                borderTop: "1px solid #E5E7EB",
                display: "flex",
                gap: 2,
              }}
            >
              <Button
                type="submit"
                variant="contained"
              >
                Apply Leave
              </Button>

              <Button
                variant="outlined"
                onClick={() => navigate("/leave")}
              >
                Cancel
              </Button>
            </Box>

          </Box>

        </CardContent>
      </Card>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        onClose={() => setOpenSnackbar(false)}
      >
        <Alert
          severity="success"
          variant="filled"
          onClose={() => setOpenSnackbar(false)}
        >
          Leave applied successfully!
        </Alert>
      </Snackbar>

    </PageContainer>
  );
}

export default ApplyLeave;