import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Divider,
  TextField,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import EditIcon from "@mui/icons-material/Edit";
import EventAvailableIcon from "@mui/icons-material/EventAvailable";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import leaveService from "../../services/leaveService";

function ViewLeave() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [leave, setLeave] = useState(null);

  useEffect(() => {
    loadLeave();
  }, []);

  const loadLeave = async () => {
    try {
      const response = await leaveService.getLeaveById(id);
      setLeave(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const getStatusColor = (status) => {
    switch ((status || "").toUpperCase()) {
      case "APPROVED":
        return "success";
      case "REJECTED":
        return "error";
      case "PENDING":
        return "warning";
      default:
        return "default";
    }
  };

  if (!leave) {
    return (
      <PageContainer>
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          minHeight="60vh"
        >
          <CircularProgress size={45} />
        </Box>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Leave",
            path: "/leave",
          },
          {
            label: "View Leave",
          },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          maxWidth: 1100,
          mx: "auto",
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <Box
            display="flex"
            alignItems="center"
            gap={2}
            mb={3}
          >
            <EventAvailableIcon
              sx={{
                fontSize: 42,
                color: "primary.main",
              }}
            />

            <Box>
              <Typography
                variant="h5"
                fontWeight={700}
              >
                Leave Details
              </Typography>

              <Typography
                variant="body2"
                color="text.secondary"
              >
                Employee leave request information.
              </Typography>
            </Box>
          </Box>

          <Divider sx={{ mb: 4 }} />

          <Grid container spacing={3}>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                label="Leave Code"
                value={leave.leaveCode || ""}
                slotProps={{
                  input: { readOnly: true },
                  inputLabel: { shrink: true },
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                label="Employee"
                value={
                  leave.employeeName ||
                  `${leave.employee?.firstName || ""} ${
                    leave.employee?.lastName || ""
                  }`
                }
                slotProps={{
                  input: { readOnly: true },
                  inputLabel: { shrink: true },
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                label="Leave Type"
                value={leave.leaveType || ""}
                slotProps={{
                  input: { readOnly: true },
                  inputLabel: { shrink: true },
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                label="Number of Days"
                value={leave.numberOfDays || ""}
                slotProps={{
                  input: { readOnly: true },
                  inputLabel: { shrink: true },
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                type="date"
                label="Start Date"
                value={leave.startDate || ""}
                slotProps={{
                  input: { readOnly: true },
                  inputLabel: { shrink: true },
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                type="date"
                label="End Date"
                value={leave.endDate || ""}
                slotProps={{
                  input: { readOnly: true },
                  inputLabel: { shrink: true },
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                fullWidth
                type="date"
                label="Applied Date"
                value={leave.appliedDate || ""}
                slotProps={{
                  input: { readOnly: true },
                  inputLabel: { shrink: true },
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Typography
                variant="subtitle2"
                mb={1}
                fontWeight={600}
              >
                Status
              </Typography>

              <Chip
                label={leave.status}
                color={getStatusColor(leave.status)}
                sx={{
                  fontWeight: 700,
                }}
              />
            </Grid>

            <Grid size={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Reason"
                value={leave.reason || ""}
                slotProps={{
                  input: { readOnly: true },
                  inputLabel: { shrink: true },
                }}
              />
            </Grid>

            <Grid size={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Remarks"
                value={leave.remarks || ""}
                slotProps={{
                  input: { readOnly: true },
                  inputLabel: { shrink: true },
                }}
              />
            </Grid>

            {leave.status &&
              leave.status.toUpperCase() !== "PENDING" && (
                <Grid size={{ xs: 12, md: 6 }}>
                  <TextField
                    fullWidth
                    label="Approved By"
                    value={leave.approvedBy || "-"}
                    slotProps={{
                      input: { readOnly: true },
                      inputLabel: { shrink: true },
                    }}
                  />
                </Grid>
              )}
          </Grid>

          <Divider sx={{ my: 4 }} />

          <Box
            display="flex"
            justifyContent="flex-end"
            gap={2}
          >
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/leave")}
            >
              Back
            </Button>

            <Button
              variant="contained"
              startIcon={<EditIcon />}
              onClick={() => navigate(`/leave/edit/${leave.id}`)}
            >
              Edit Leave
            </Button>
          </Box>
        </CardContent>
      </Card>
    </PageContainer>
  );
}

export default ViewLeave;