import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Card,
  CardContent,
  Divider,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";
import TablePagination from "@mui/material/TablePagination";

import PageContainer from "../../components/common/PageContainer";
import PageToolbar from "../../components/common/PageToolbar";

import LeaveTable from "../../components/tables/LeaveTable";
import leaveService from "../../services/leaveService";

function LeaveList() {
  const navigate = useNavigate();

  const [leaves, setLeaves] = useState([]);
  const [search, setSearch] = useState("");

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [totalElements, setTotalElements] = useState(0);

  useEffect(() => {
    loadLeaves();
  }, [page, rowsPerPage]);

  const loadLeaves = async () => {
    try {
      const response = await leaveService.getLeaves(
        page,
        rowsPerPage
      );

      setLeaves(response.data.content);
      setTotalElements(response.data.totalElements);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSearch = async (value) => {
    setSearch(value);

    try {
      if (value.trim() === "") {
        loadLeaves();
      } else {
        const response =
          await leaveService.searchLeaves(value);

        setLeaves(response.data);
        setTotalElements(response.data.length);
        setPage(0);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleApprove = async (id) => {
    try {
      await leaveService.approveLeave(id);

      alert("Leave Approved Successfully");

      loadLeaves();
    } catch (error) {
      console.error(error);
    }
  };

  const handleReject = async (id) => {
    try {
      await leaveService.rejectLeave(id);

      alert("Leave Rejected Successfully");

      loadLeaves();
    } catch (error) {
      console.error(error);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this leave request?")) return;

    try {
      await leaveService.deleteLeave(id);

      alert("Leave deleted successfully.");

      loadLeaves();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <PageContainer>

      {/* Header */}

      <Box mb={3}>
        <PageToolbar
          buttonText="+ Apply Leave"
          onAdd={() => navigate("/leave/add")}
          search={search}
          onSearch={(e) => handleSearch(e.target.value)}
        />
      </Box>

      {/* Filter Section */}

      <Card
        elevation={0}
        sx={{
          mb: 3,
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 3 }}>
          <Typography
            fontWeight={700}
            mb={2}
          >
            Leave Filters
          </Typography>

          <Divider sx={{ mb: 3 }} />

          <Grid
            container
            spacing={3}
          >
            <Grid size={{ xs: 12, md: 6, lg: 3 }}>
              <TextField
                fullWidth
                size="small"
                label="Status"
                select
                defaultValue=""
              >
                <MenuItem value="">
                  All Status
                </MenuItem>

                <MenuItem value="PENDING">
                  Pending
                </MenuItem>

                <MenuItem value="APPROVED">
                  Approved
                </MenuItem>

                <MenuItem value="REJECTED">
                  Rejected
                </MenuItem>
              </TextField>
            </Grid>

            <Grid size={{ xs: 12, md: 6, lg: 3 }}>
              <TextField
                fullWidth
                size="small"
                label="Leave Type"
                select
                defaultValue=""
              >
                <MenuItem value="">
                  All Types
                </MenuItem>

                <MenuItem value="Casual">
                  Casual
                </MenuItem>

                <MenuItem value="Sick">
                  Sick
                </MenuItem>

                <MenuItem value="Paid">
                  Paid
                </MenuItem>

                <MenuItem value="Loss Of Pay">
                  Loss Of Pay
                </MenuItem>
              </TextField>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Leave Table */}

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 0 }}>
          <LeaveTable
            leaves={leaves}
            onDelete={handleDelete}
            loadLeaves={loadLeaves}
            onApprove={handleApprove}
            onReject={handleReject}
          />
        </CardContent>
      </Card>

      {/* Pagination */}

      <Box
        display="flex"
        justifyContent="flex-end"
        mt={2}
      >
        <TablePagination
          component="div"
          count={totalElements}
          page={page}
          rowsPerPage={rowsPerPage}
          onPageChange={(event, newPage) =>
            setPage(newPage)
          }
          onRowsPerPageChange={(event) => {
            setRowsPerPage(
              parseInt(event.target.value, 10)
            );
            setPage(0);
          }}
        />
      </Box>

    </PageContainer>
  );
}

export default LeaveList;