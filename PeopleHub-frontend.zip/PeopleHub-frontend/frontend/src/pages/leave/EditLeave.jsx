import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  CardContent,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import SaveIcon from "@mui/icons-material/Save";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import leaveService from "../../services/leaveService";
import employeeService from "../../services/employeeService";

function EditLeave() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    employeeId: "",
    leaveType: "",
    startDate: "",
    endDate: "",
    reason: "",
    remarks: "",
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    loadEmployees();
    loadLeave();
  }, []);

  const loadEmployees = async () => {
    try {
      const response = await employeeService.getAllEmployees();

      setEmployees(
        response.data.content ? response.data.content : response.data
      );
    } catch (error) {
      console.error(error);
    }
  };

  const loadLeave = async () => {
    try {
      const response = await leaveService.getLeaveById(id);

      const leave = response.data;

      setFormData({
        employeeId: leave.employeeId || leave.employee?.id || "",
        leaveType: leave.leaveType || "",
        startDate: leave.startDate || "",
        endDate: leave.endDate || "",
        reason: leave.reason || "",
        remarks: leave.remarks || "",
      });
    } catch (error) {
      console.error(error);
      alert("Unable to load leave details.");
    }
  };

  const validate = () => {
    let temp = {};

    if (!formData.employeeId)
      temp.employeeId = "Employee is required";

    if (!formData.leaveType)
      temp.leaveType = "Leave Type is required";

    if (!formData.startDate)
      temp.startDate = "Start Date is required";

    if (!formData.endDate)
      temp.endDate = "End Date is required";

    if (
      formData.startDate &&
      formData.endDate &&
      formData.endDate < formData.startDate
    ) {
      temp.endDate =
        "End Date cannot be earlier than Start Date";
    }

    if (!formData.reason.trim())
      temp.reason = "Reason is required";

    setErrors(temp);

    return Object.keys(temp).length === 0;
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) return;

    try {
      setLoading(true);

      await leaveService.updateLeave(id, {
        employeeId: Number(formData.employeeId),
        leaveType: formData.leaveType,
        startDate: formData.startDate,
        endDate: formData.endDate,
        reason: formData.reason,
        remarks: formData.remarks,
      });

      alert("Leave Updated Successfully");

      navigate("/leave");
    } catch (error) {
      console.error(error);

      alert(
        error.response?.data?.message ||
          "Unable to update leave."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageContainer>
      <PageHeader
        title="Edit Leave"
        subtitle="Update employee leave request."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Leave",
            path: "/leave",
          },
          {
            label: "Edit Leave",
          },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          maxWidth: 900,
          mx: "auto",
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <Box component="form" onSubmit={handleSubmit}>
            <Grid container spacing={3}>
              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  select
                  label="Employee"
                  name="employeeId"
                  value={formData.employeeId}
                  onChange={handleChange}
                  error={Boolean(errors.employeeId)}
                  helperText={errors.employeeId}
                >
                  {employees.map((emp) => (
                    <MenuItem
                      key={emp.id}
                      value={emp.id}
                    >
                      {emp.firstName} {emp.lastName}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  select
                  label="Leave Type"
                  name="leaveType"
                  value={formData.leaveType}
                  onChange={handleChange}
                  error={Boolean(errors.leaveType)}
                  helperText={errors.leaveType}
                >
                  <MenuItem value="Casual">
                    Casual
                  </MenuItem>
                  <MenuItem value="Sick">
                    Sick
                  </MenuItem>
                  <MenuItem value="Paid">
                    Paid
                  </MenuItem>
                  <MenuItem value="Loss Of Pay">
                    Loss Of Pay
                  </MenuItem>
                </TextField>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  type="date"
                  label="Start Date"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleChange}
                  error={Boolean(errors.startDate)}
                  helperText={errors.startDate}
                  slotProps={{
                    inputLabel: {
                      shrink: true,
                    },
                  }}
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  type="date"
                  label="End Date"
                  name="endDate"
                  value={formData.endDate}
                  onChange={handleChange}
                  error={Boolean(errors.endDate)}
                  helperText={errors.endDate}
                  slotProps={{
                    inputLabel: {
                      shrink: true,
                    },
                  }}
                />
              </Grid>

              <Grid size={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={3}
                  label="Reason"
                  name="reason"
                  value={formData.reason}
                  onChange={handleChange}
                  error={Boolean(errors.reason)}
                  helperText={errors.reason}
                />
              </Grid>

              <Grid size={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={3}
                  label="Remarks"
                  name="remarks"
                  value={formData.remarks}
                  onChange={handleChange}
                />
              </Grid>

              <Grid size={12}>
                <Box
                  display="flex"
                  justifyContent="flex-end"
                  gap={2}
                >
                  <Button
                    variant="outlined"
                    startIcon={<ArrowBackIcon />}
                    onClick={() => navigate("/leave")}
                  >
                    Cancel
                  </Button>

                  <Button
                    type="submit"
                    variant="contained"
                    startIcon={<SaveIcon />}
                    disabled={loading}
                  >
                    {loading
                      ? "Updating..."
                      : "Update Leave"}
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </CardContent>
      </Card>
    </PageContainer>
  );
}

export default EditLeave;