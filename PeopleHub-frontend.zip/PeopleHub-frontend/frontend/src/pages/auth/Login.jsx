import { Navigate } from "react-router-dom";
import { Card, CardContent, Typography } from "@mui/material";

import AuthLayout from "../../components/layout/AuthLayout";
import LoginForm from "../../components/forms/LoginForm";

function Login() {

  const token = localStorage.getItem("token");

  // If already logged in, redirect to dashboard
  if (token) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <AuthLayout>
      <Card
        sx={{
          width: 420,
          borderRadius: 4,
          boxShadow: 8,
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <Typography
            variant="h4"
            align="center"
            color="primary"
            gutterBottom
          >
            Welcome Back
          </Typography>

          <Typography
            align="center"
            color="text.secondary"
            sx={{ mb: 3 }}
          >
            Sign in to continue
          </Typography>

          <LoginForm />
        </CardContent>
      </Card>
    </AuthLayout>
  );
}

export default Login;