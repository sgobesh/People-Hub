import { useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  TextField,
  Typography,
  InputAdornment,
  IconButton,
} from "@mui/material";

import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import LockResetRoundedIcon from "@mui/icons-material/LockResetRounded";

import authService from "../../services/authService";


function ForgotPassword() {


  const navigate = useNavigate();


  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");

  const [confirmPassword, setConfirmPassword] = useState("");


  const [showPassword, setShowPassword] = useState(false);

  const [showConfirmPassword, setShowConfirmPassword] = useState(false);



  const handleSubmit = async () => {


    if (!email) {

      alert("Email is required");

      return;

    }



    if (!password) {

      alert("New password is required");

      return;

    }



    if (password.length < 8) {

      alert(
        "Password must contain minimum 8 characters"
      );

      return;

    }



    if (password !== confirmPassword) {

      alert(
        "Passwords do not match"
      );

      return;

    }




    try {


      await authService.resetPassword({

        email: email,

        newPassword: password,

      });




      alert(
        "Password updated successfully"
      );



      navigate("/login");



    } catch (error) {


      alert(

        error.response?.data ||
        "Password reset failed"

      );


    }


  };





  return (


    <Box

      sx={{

        minHeight:"100vh",

        display:"flex",

        justifyContent:"center",

        alignItems:"center",

        bgcolor:"#F5F7FB"

      }}

    >



      <Card

        sx={{

          width:420,

          p:4,

          borderRadius:4,

          boxShadow:
          "0 10px 30px rgba(0,0,0,.08)"

        }}

      >



        <Box

          textAlign="center"

          mb={3}

        >


          <LockResetRoundedIcon

            color="primary"

            sx={{

              fontSize:55

            }}

          />



          <Typography

            variant="h5"

            fontWeight={700}

          >

            Reset Password

          </Typography>


          <Typography

            color="text.secondary"

            mt={1}

          >

            Enter your email and create a new password

          </Typography>


        </Box>






        <TextField

          fullWidth

          label="Email Address"

          placeholder="Enter your email"

          value={email}

          onChange={(e)=>
            setEmail(e.target.value)
          }

          margin="normal"

        />






        <TextField

          fullWidth

          label="New Password"

          type={
            showPassword
            ? "text"
            : "password"
          }

          value={password}

          onChange={(e)=>
            setPassword(e.target.value)
          }

          margin="normal"


          InputProps={{

            endAdornment:(

              <InputAdornment position="end">

                <IconButton

                  onClick={()=>
                    setShowPassword(!showPassword)
                  }

                >

                  {
                    showPassword
                    ?
                    <VisibilityOff/>
                    :
                    <Visibility/>
                  }

                </IconButton>


              </InputAdornment>

            )

          }}

        />







        <TextField

          fullWidth

          label="Confirm Password"

          type={
            showConfirmPassword
            ? "text"
            : "password"
          }

          value={confirmPassword}

          onChange={(e)=>
            setConfirmPassword(e.target.value)
          }

          margin="normal"


          InputProps={{

            endAdornment:(

              <InputAdornment position="end">

                <IconButton

                  onClick={()=>
                    setShowConfirmPassword(
                      !showConfirmPassword
                    )
                  }

                >

                  {
                    showConfirmPassword
                    ?
                    <VisibilityOff/>
                    :
                    <Visibility/>
                  }


                </IconButton>


              </InputAdornment>

            )

          }}

        />







        <Button


          fullWidth


          variant="contained"


          size="large"


          onClick={handleSubmit}



          sx={{

            mt:3,

            py:1.5,

            borderRadius:3,

            fontWeight:700,

            textTransform:"none"

          }}


        >

          Update Password


        </Button>





      </Card>


    </Box>


  );


}


export default ForgotPassword;