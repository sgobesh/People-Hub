import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Card,
  CardContent,
  Divider,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";
import TablePagination from "@mui/material/TablePagination";

import PageContainer from "../../components/common/PageContainer";
import PageToolbar from "../../components/common/PageToolbar";

import DepartmentTable from "../../components/tables/DepartmentTable";
import departmentService from "../../services/departmentService";

function DepartmentList() {
  const navigate = useNavigate();

  const [departments, setDepartments] = useState([]);
  const [search, setSearch] = useState("");

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [totalElements, setTotalElements] = useState(0);

  useEffect(() => {
    loadDepartments();
  }, [page, rowsPerPage]);

  const loadDepartments = async () => {
    try {
      const response = await departmentService.getDepartments(
        page,
        rowsPerPage
      );

      setDepartments(response.data.content);
      setTotalElements(response.data.totalElements);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSearch = async (value) => {
    setSearch(value);

    try {
      if (value.trim() === "") {
        loadDepartments();
      } else {
        const response =
          await departmentService.searchDepartments(value);

        setDepartments(response.data);
        setTotalElements(response.data.length);
        setPage(0);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this department?")) return;

    try {
      await departmentService.deleteDepartment(id);

      alert("Department deleted successfully.");

      loadDepartments();
    } catch (error) {
      console.error(error);
      alert("Unable to delete department.");
    }
  };

  return (
    <PageContainer>

      {/* Header Toolbar */}

      <Box mb={3}>
        <PageToolbar
          buttonText="+ Add Department"
          onAdd={() => navigate("/departments/add")}
          search={search}
          onSearch={(e) => handleSearch(e.target.value)}
        />
      </Box>

      {/* Filter Section */}

      <Card
        elevation={0}
        sx={{
          mb: 3,
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 3 }}>
          <Typography
            fontWeight={700}
            mb={2}
          >
            Department Filters
          </Typography>

          <Divider sx={{ mb: 3 }} />

          <Grid container spacing={3}>
            <Grid size={{ xs: 12, md: 6, lg: 3 }}>
              <TextField
                fullWidth
                size="small"
                label="Department"
                select
                defaultValue=""
              >
                <MenuItem value="">
                  All Departments
                </MenuItem>

                {departments.map((dept) => (
                  <MenuItem
                    key={dept.id}
                    value={dept.departmentName}
                  >
                    {dept.departmentName}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Department Table */}

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 0 }}>
          <DepartmentTable
            departments={departments}
            onDelete={handleDelete}
          />
        </CardContent>
      </Card>

      {/* Pagination */}

      <Box
        display="flex"
        justifyContent="flex-end"
        mt={2}
      >
        <TablePagination
          component="div"
          count={totalElements}
          page={page}
          rowsPerPage={rowsPerPage}
          onPageChange={(event, newPage) =>
            setPage(newPage)
          }
          onRowsPerPageChange={(event) => {
            setRowsPerPage(
              parseInt(event.target.value, 10)
            );
            setPage(0);
          }}
        />
      </Box>

    </PageContainer>
  );
}

export default DepartmentList;