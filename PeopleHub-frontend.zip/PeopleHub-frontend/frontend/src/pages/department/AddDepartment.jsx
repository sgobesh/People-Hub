import { useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  CardContent,
  Divider,
  TextField,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";

import departmentService from "../../services/departmentService";

function AddDepartment() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    departmentName: "",
    departmentHead: "",
    description: "",
  });

  const [errors, setErrors] = useState({});

  const validate = () => {
    let temp = {};

    if (!formData.departmentName.trim()) {
      temp.departmentName = "Department Name is required";
    }

    if (!formData.departmentHead.trim()) {
      temp.departmentHead = "Department Head is required";
    }

    if (!formData.description.trim()) {
      temp.description = "Description is required";
    }

    setErrors(temp);

    return Object.keys(temp).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) return;

    try {
      await departmentService.addDepartment(formData);

      alert("Department added successfully!");

      navigate("/departments");
    } catch (error) {
      console.error(error);
      alert("Unable to add department.");
    }
  };

  return (
    <PageContainer>
      <PageHeader
        title="Add Department"
        subtitle="Create a new department for your organization."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Departments",
            path: "/departments",
          },
          {
            label: "Add Department",
          },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <Typography
            variant="h6"
            fontWeight={700}
            mb={3}
          >
            Department Information
          </Typography>

          <Divider sx={{ mb: 4 }} />

          <Box
            component="form"
            onSubmit={handleSubmit}
          >
            <Grid container spacing={3}>

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  label="Department Name"
                  name="departmentName"
                  value={formData.departmentName}
                  onChange={handleChange}
                  error={Boolean(errors.departmentName)}
                  helperText={errors.departmentName}
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  label="Department Head"
                  name="departmentHead"
                  value={formData.departmentHead}
                  onChange={handleChange}
                  error={Boolean(errors.departmentHead)}
                  helperText={errors.departmentHead}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <TextField
                  fullWidth
                  multiline
                  rows={5}
                  label="Description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  error={Boolean(errors.description)}
                  helperText={errors.description}
                />
              </Grid>

            </Grid>

            <Divider sx={{ my: 4 }} />

            <Box
              display="flex"
              justifyContent="flex-end"
              gap={2}
            >
              <Button
                variant="outlined"
                startIcon={<CancelIcon />}
                onClick={() => navigate("/departments")}
              >
                Cancel
              </Button>

              <Button
                type="submit"
                variant="contained"
                startIcon={<SaveIcon />}
              >
                Save Department
              </Button>
            </Box>

          </Box>
        </CardContent>
      </Card>
    </PageContainer>
  );
}

export default AddDepartment;