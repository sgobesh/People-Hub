import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import departmentService from "../../services/departmentService";

import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Divider,
  Paper,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import EditIcon from "@mui/icons-material/Edit";
import BusinessIcon from "@mui/icons-material/Business";
import PersonIcon from "@mui/icons-material/Person";
import DescriptionIcon from "@mui/icons-material/Description";

function ViewDepartment() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [department, setDepartment] = useState(null);

  useEffect(() => {
    loadDepartment();
  }, []);

  const loadDepartment = async () => {
    try {
      const response =
        await departmentService.getDepartmentById(id);

      setDepartment(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  if (!department) {
    return (
      <PageContainer>
        <Box
          sx={{
            height: "70vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <CircularProgress size={55} />
        </Box>
      </PageContainer>
    );
  }

  return (
    <PageContainer>

      <PageHeader
        title="Department Details"
        subtitle="View complete department information."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Departments",
            path: "/departments",
          },
          {
            label: "View Department",
          },
        ]}
        actions={
          <>
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/departments")}
            >
              Back
            </Button>

            <Button
              variant="contained"
              startIcon={<EditIcon />}
              onClick={() =>
                navigate(`/departments/edit/${department.id}`)
              }
            >
              Edit Department
            </Button>
          </>
        }
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 4 }}>

          {/* Profile Header */}

          <Box
            sx={{
              display: "flex",
              flexDirection: {
                xs: "column",
                md: "row",
              },
              alignItems: "center",
              gap: 4,
              mb: 5,
            }}
          >
            <Avatar
              sx={{
                width: 110,
                height: 110,
                bgcolor: "primary.main",
                fontSize: 42,
                fontWeight: 700,
              }}
            >
              {department.departmentName?.charAt(0)}
            </Avatar>

            <Box flex={1}>
              <Typography
                variant="h4"
                fontWeight={700}
              >
                {department.departmentName}
              </Typography>

              <Typography
                color="text.secondary"
                mt={1}
              >
                Department Information
              </Typography>

              <Box
                mt={2}
                display="flex"
                gap={2}
                flexWrap="wrap"
              >
                <Chip
                  color="primary"
                  label={department.departmentCode}
                />
              </Box>
            </Box>
          </Box>

          <Divider sx={{ mb: 4 }} />

          <Grid container spacing={3}>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E8F5E9",
                      color: "#2E7D32",
                    }}
                  >
                    <BusinessIcon />
                  </Avatar>

                  <Box>
                    <Typography
                      fontSize={14}
                      color="text.secondary"
                    >
                      Department Code
                    </Typography>

                    <Typography fontWeight={600}>
                      {department.departmentCode}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#FFF3E0",
                      color: "#FB8C00",
                    }}
                  >
                    <PersonIcon />
                  </Avatar>

                  <Box>
                    <Typography
                      fontSize={14}
                      color="text.secondary"
                    >
                      Department Head
                    </Typography>

                    <Typography fontWeight={600}>
                      {department.departmentHead}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

            <Grid size={{ xs: 12 }}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  border: "1px solid #E5E7EB",
                }}
              >
                <Box display="flex" gap={2}>
                  <Avatar
                    sx={{
                      bgcolor: "#E3F2FD",
                      color: "#1976D2",
                    }}
                  >
                    <DescriptionIcon />
                  </Avatar>

                  <Box>
                    <Typography
                      fontSize={14}
                      color="text.secondary"
                    >
                      Description
                    </Typography>

                    <Typography
                      fontWeight={500}
                      sx={{ mt: 1 }}
                    >
                      {department.description || "-"}
                    </Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>

          </Grid>

          <Divider sx={{ my: 4 }} />

          <Box
            display="flex"
            justifyContent="flex-end"
            gap={2}
            flexWrap="wrap"
          >
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/departments")}
            >
              Back
            </Button>

            <Button
              variant="contained"
              startIcon={<EditIcon />}
              onClick={() =>
                navigate(`/departments/edit/${department.id}`)
              }
            >
              Edit Department
            </Button>
          </Box>

        </CardContent>
      </Card>

    </PageContainer>
  );
}

export default ViewDepartment;