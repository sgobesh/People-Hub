import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  CardContent,
  Divider,
  Snackbar,
  Alert,
  TextField,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import departmentService from "../../services/departmentService";

function EditDepartment() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    departmentName: "",
    departmentHead: "",
    description: "",
  });

  const [errors, setErrors] = useState({});
  const [openSnackbar, setOpenSnackbar] = useState(false);

  useEffect(() => {
    loadDepartment();
  }, []);

  const loadDepartment = async () => {
    try {
      const response = await departmentService.getDepartmentById(id);

      setFormData({
        departmentName: response.data.departmentName || "",
        departmentHead: response.data.departmentHead || "",
        description: response.data.description || "",
      });
    } catch (error) {
      console.error(error);
      alert("Unable to load department.");
    }
  };

  const validate = () => {
    let temp = {};

    if (!formData.departmentName.trim()) {
      temp.departmentName = "Department Name is required";
    }

    if (!formData.departmentHead.trim()) {
      temp.departmentHead = "Department Head is required";
    }

    if (!formData.description.trim()) {
      temp.description = "Description is required";
    }

    setErrors(temp);

    return Object.keys(temp).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) return;

    try {
      await departmentService.updateDepartment(id, formData);

      setOpenSnackbar(true);

      setTimeout(() => {
        navigate("/departments");
      }, 1000);
    } catch (error) {
      console.error(error);
      alert("Unable to update department.");
    }
  };

  return (
    <PageContainer>
      <PageHeader
        title="Edit Department"
        subtitle="Update department information."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Departments",
            path: "/departments",
          },
          {
            label: "Edit Department",
          },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <Typography
            variant="h6"
            fontWeight={700}
            mb={3}
          >
            Department Information
          </Typography>

          <Divider sx={{ mb: 4 }} />

          <Box component="form" onSubmit={handleSubmit}>
            <Grid container spacing={3}>

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  label="Department Name"
                  name="departmentName"
                  value={formData.departmentName}
                  onChange={handleChange}
                  error={Boolean(errors.departmentName)}
                  helperText={errors.departmentName}
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <TextField
                  fullWidth
                  label="Department Head"
                  name="departmentHead"
                  value={formData.departmentHead}
                  onChange={handleChange}
                  error={Boolean(errors.departmentHead)}
                  helperText={errors.departmentHead}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <TextField
                  fullWidth
                  multiline
                  rows={5}
                  label="Description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  error={Boolean(errors.description)}
                  helperText={errors.description}
                />
              </Grid>

            </Grid>

            <Divider sx={{ my: 4 }} />

            <Box
              display="flex"
              justifyContent="flex-end"
              gap={2}
            >
              <Button
                variant="outlined"
                startIcon={<CancelIcon />}
                onClick={() => navigate("/departments")}
              >
                Cancel
              </Button>

              <Button
                type="submit"
                variant="contained"
                startIcon={<SaveIcon />}
              >
                Update Department
              </Button>
            </Box>
          </Box>
        </CardContent>
      </Card>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={() => setOpenSnackbar(false)}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
      >
        <Alert
          severity="success"
          variant="filled"
          onClose={() => setOpenSnackbar(false)}
        >
          Department updated successfully!
        </Alert>
      </Snackbar>
    </PageContainer>
  );
}

export default EditDepartment;