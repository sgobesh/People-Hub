import { useEffect, useState } from "react";

import {
  Avatar,
  Box,
  Card,
  CardContent,
  CircularProgress,
  List,
  Typography,
} from "@mui/material";

import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";

import PageContainer from "../../components/common/PageContainer";

import notificationService from "../../services/notificationService";
import NotificationItem from "../../components/notification/NotificationItem";

function NotificationList() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] =useState(true);

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    try {
      setLoading(true);

      const response =
        await notificationService.getAllNotifications();

      setNotifications(response.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <PageContainer>
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          minHeight="60vh"
        >
          <CircularProgress size={45} />
        </Box>
      </PageContainer>
    );
  }

  return (
    <PageContainer>

      {/* Header */}

      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        flexWrap="wrap"
        gap={2}
        mb={3}
      >
        <Box display="flex" alignItems="center" gap={2}>
          <Avatar
            sx={{
              bgcolor: "primary.main",
              width: 60,
              height: 60,
            }}
          >
            <NotificationsActiveIcon fontSize="large" />
          </Avatar>

          <Typography
            variant="h4"
            fontWeight="bold"
          >
          
          </Typography>
        </Box>

        <Card
          elevation={0}
          sx={{
            borderRadius: 3,
            border: "1px solid #E5E7EB",
            minWidth: 170,
            bgcolor: "#F8FAFC",
          }}
        >
          <CardContent sx={{ py: 2 }}>
            <Typography
              variant="body2"
              color="text.secondary"
            >
              Total Notifications
            </Typography>

            <Typography
              variant="h4"
              fontWeight="bold"
              color="primary"
            >
              {notifications.length}
            </Typography>
          </CardContent>
        </Card>
      </Box>

      {/* Notification List */}

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 0 }}>

          {notifications.length === 0 ? (
            <Box
              py={10}
              textAlign="center"
            >
              <NotificationsActiveIcon
                sx={{
                  fontSize: 80,
                  color: "#D1D5DB",
                  mb: 2,
                }}
              />

              <Typography
                variant="h6"
                fontWeight="bold"
              >
                No Notifications
              </Typography>

              <Typography
                color="text.secondary"
                mt={1}
              >
                New HR updates and system alerts will appear here.
              </Typography>
            </Box>
          ) : (
            <List sx={{ p: 0 }}>
              {notifications.map((notification) => (
                <NotificationItem
                  key={notification.id}
                  notification={notification}
                  refresh={loadNotifications}
                />
              ))}
            </List>
          )}

        </CardContent>
      </Card>

    </PageContainer>
  );
}

export default NotificationList;