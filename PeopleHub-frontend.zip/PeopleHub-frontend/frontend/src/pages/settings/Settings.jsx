import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";

import {
  Box,
  Card,
  CardContent,
  Tab,
  Tabs,
} from "@mui/material";

import BusinessIcon from "@mui/icons-material/Business";
import PersonIcon from "@mui/icons-material/Person";
import LockIcon from "@mui/icons-material/Lock";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import CompanySettings from "./CompanySettings";
import ProfileSettings from "./ProfileSettings";
import ChangePassword from "./ChangePassword";


function Settings() {


  const [searchParams] = useSearchParams();


  const [tab,setTab] = useState(0);



  useEffect(()=>{


    const selectedTab = searchParams.get("tab");


    if(selectedTab === "profile"){

      setTab(1);

    }
    else if(selectedTab === "password"){

      setTab(2);

    }
    else{

      setTab(0);

    }


  },[searchParams]);





  return (

    <PageContainer>


      <PageHeader

        breadcrumbs={[

          {
            label:"Dashboard",
            path:"/dashboard",
          },

          {
            label:"Settings",
          },

        ]}

      />





      <Card

        elevation={0}

        sx={{

          borderRadius:4,

          border:"1px solid #E5E7EB",

          mb:3,

        }}

      >


        <CardContent sx={{p:1}}>


          <Tabs

            value={tab}

            onChange={(event,value)=>setTab(value)}

            variant="fullWidth"

            textColor="primary"

            indicatorColor="primary"

            sx={{

              "& .MuiTab-root":{

                minHeight:70,

                fontWeight:600,

                fontSize:15,

                textTransform:"none",

              }

            }}

          >



            <Tab

              icon={<BusinessIcon/>}

              iconPosition="start"

              label="Company"

            />



            <Tab

              icon={<PersonIcon/>}

              iconPosition="start"

              label="My Profile"

            />



            <Tab

              icon={<LockIcon/>}

              iconPosition="start"

              label="Change Password"

            />



          </Tabs>


        </CardContent>


      </Card>






      <Box>


        {
          tab === 0 && <CompanySettings/>
        }


        {
          tab === 1 && <ProfileSettings/>
        }


        {
          tab === 2 && <ChangePassword/>
        }


      </Box>



    </PageContainer>

  );

}


export default Settings;