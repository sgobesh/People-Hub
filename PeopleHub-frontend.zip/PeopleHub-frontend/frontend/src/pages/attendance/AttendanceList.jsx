import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Card,
  CardContent,
  Divider,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import PageContainer from "../../components/common/PageContainer";
import PageToolbar from "../../components/common/PageToolbar";
import AttendanceTable from "../../components/tables/AttendanceTable";

import attendanceService from "../../services/attendanceService";

function AttendanceList() {
  const navigate = useNavigate();

  const [attendance, setAttendance] = useState([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    loadAttendance();
  }, []);

  const loadAttendance = async () => {
    try {
      const response = await attendanceService.getAllAttendance();
      setAttendance(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete?")) return;

    try {
      await attendanceService.deleteAttendance(id);
      loadAttendance();
    } catch (error) {
      console.error(error);
    }
  };

  const filteredAttendance = attendance.filter((item) => {
    const matchesSearch =
      item.employeeName
        ?.toLowerCase()
        .includes(search.toLowerCase());

    const matchesStatus =
      status === "" || item.status === status;

    return matchesSearch && matchesStatus;
  });

  return (
    <PageContainer>

      {/* Header Toolbar */}

      <Box mb={3}>
        <PageToolbar
          buttonText="+ Mark Attendance"
          onAdd={() => navigate("/attendance/add")}
          search={search}
          onSearch={(e) => setSearch(e.target.value)}
        />
      </Box>

      {/* Filter Section */}

      <Card
        elevation={0}
        sx={{
          mb: 3,
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 3 }}>
          <Typography
            fontWeight={700}
            mb={2}
          >
            Attendance Filters
          </Typography>

          <Divider sx={{ mb: 3 }} />

          <Grid container spacing={3}>

            <Grid size={{ xs: 12, md: 6, lg: 3 }}>
              <TextField
                fullWidth
                size="small"
                select
                label="Status"
                value={status}
                onChange={(e) =>
                  setStatus(e.target.value)
                }
              >
                <MenuItem value="">
                  All Status
                </MenuItem>

                <MenuItem value="PRESENT">
                  Present
                </MenuItem>

                <MenuItem value="ABSENT">
                  Absent
                </MenuItem>

                <MenuItem value="LEAVE">
                  Leave
                </MenuItem>

                <MenuItem value="LATE">
                  Late
                </MenuItem>

                <MenuItem value="HALF_DAY">
                  Half Day
                </MenuItem>
              </TextField>
            </Grid>

          </Grid>
        </CardContent>
      </Card>

      {/* Attendance Table */}

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 0 }}>
          <AttendanceTable
            attendance={filteredAttendance}
            onDelete={handleDelete}
          />
        </CardContent>
      </Card>

    </PageContainer>
  );
}

export default AttendanceList;