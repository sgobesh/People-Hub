import {
  useEffect,
  useState
} from "react";
import {
  useNavigate,
  useParams
} from "react-router-dom";

import employeeService from "../../services/employeeService";
import attendanceService from "../../services/attendanceService";

import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Divider,
  MenuItem,
  Snackbar,
  TextField,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import SaveIcon from "@mui/icons-material/Save";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

function EditAttendance() {

  const {
    id
  } = useParams();
  const navigate = useNavigate();

  const [employees, setEmployees] = useState([]);

  const [formData, setFormData] = useState({

    employeeId: "",
    attendanceDate: "",
    checkIn: "",
    checkOut: "",
    status: "PRESENT",

  });

  const [errors, setErrors] = useState({});
  const [openSnackbar, setOpenSnackbar] = useState(false);

  useEffect(() => {

    loadEmployees();
    loadAttendance();

  }, []);

  const loadEmployees = async () => {

    try {

      const response =
        await employeeService.getAllEmployees();

      setEmployees(response.data);

    } catch (error) {

      console.error(error);

    }

  };

  const loadAttendance = async () => {

    try {

      const response =
        await attendanceService.getAttendanceById(id);

      const data = response.data;

      setFormData({

        employeeId: data.employeeId,

        attendanceDate: data.attendanceDate,

        checkIn: data.checkIn ?
          data.checkIn.substring(0, 16) :
          "",

        checkOut: data.checkOut ?
          data.checkOut.substring(0, 16) :
          "",

        status: data.status,

      });

    } catch (error) {

      console.error(error);

    }

  };

  const handleChange = (e) => {

    const {
      name,
      value
    } = e.target;

    setFormData((prev) => ({

      ...prev,
      [name]: value

    }));

    setErrors((prev) => ({

      ...prev,
      [name]: ""

    }));

  };

  const validate = () => {

    let temp = {};

    if (!formData.employeeId)
      temp.employeeId = "Employee is required";

    if (!formData.attendanceDate)
      temp.attendanceDate = "Attendance Date is required";

    if (!formData.status)
      temp.status = "Status is required";

    setErrors(temp);

    return Object.keys(temp).length === 0;

  };

  const handleUpdate = async () => {

    if (!validate())
      return;

    try {

      await attendanceService.updateAttendance(

        id,

        {

          employeeId: Number(formData.employeeId),

          attendanceDate: formData.attendanceDate,

          checkIn: formData.checkIn || null,

          checkOut: formData.checkOut || null,

          status: formData.status

        }

      );

      setOpenSnackbar(true);

      setTimeout(() => {

        navigate("/attendance");

      }, 1200);

    } catch (error) {

      console.error(error);

      alert("Unable to update attendance");

    }

  };

  return (

    <PageContainer>



      <PageHeader

        title="Edit Attendance"

        subtitle="Update employee attendance information."

        breadcrumbs={[

          {
            label:"Dashboard",
            path:"/dashboard"
          },

          {
            label:"Attendance",
            path:"/attendance"
          },

          {
            label:"Edit Attendance"
          }

        ]}

      />





      <Card

        elevation={0}

        sx={{

          maxWidth:1000,

          mx:"auto",

          borderRadius:4,

          border:"1px solid #E5E7EB"

        }}

      >


        <CardContent sx={{p:4}}>




          <Typography

            variant="h5"

            fontWeight={700}

            mb={1}

          >

            Attendance Details

          </Typography>



          <Typography

            color="text.secondary"

            mb={3}

          >

            Modify attendance record and save changes.

          </Typography>




          <Divider sx={{mb:4}} />






          <Grid

            container

            spacing={3}

          >





            <Grid size={{xs:12,md:6}}>

              <TextField

                fullWidth

                select

                label="Employee"

                name="employeeId"

                value={formData.employeeId}

                onChange={handleChange}

                error={Boolean(errors.employeeId)}

                helperText={errors.employeeId}

              >

                <MenuItem value="">

                  Select Employee

                </MenuItem>



                {
                  employees.map((emp)=>(

                    <MenuItem

                      key={emp.id}

                      value={emp.id}

                    >

                      {emp.firstName} {emp.lastName}

                    </MenuItem>

                  ))
                }


              </TextField>

            </Grid>







            <Grid size={{xs:12,md:6}}>


              <TextField

                fullWidth

                type="date"

                label="Attendance Date"

                name="attendanceDate"

                value={formData.attendanceDate}

                onChange={handleChange}

                error={Boolean(errors.attendanceDate)}

                helperText={errors.attendanceDate}

                slotProps={{

                  inputLabel:{

                    shrink:true

                  }

                }}

              />


            </Grid>







            <Grid size={{xs:12,md:6}}>


              <TextField

                fullWidth

                type="datetime-local"

                label="Check In"

                name="checkIn"

                value={formData.checkIn}

                onChange={handleChange}

                slotProps={{

                  inputLabel:{

                    shrink:true

                  }

                }}

              />


            </Grid>








            <Grid size={{xs:12,md:6}}>


              <TextField

                fullWidth

                type="datetime-local"

                label="Check Out"

                name="checkOut"

                value={formData.checkOut}

                onChange={handleChange}

                slotProps={{

                  inputLabel:{

                    shrink:true

                  }

                }}

              />


            </Grid>








            <Grid size={{xs:12,md:6}}>


              <TextField

                fullWidth

                select

                label="Status"

                name="status"

                value={formData.status}

                onChange={handleChange}

                error={Boolean(errors.status)}

                helperText={errors.status}

              >

                <MenuItem value="PRESENT">
                  Present
                </MenuItem>


                <MenuItem value="ABSENT">
                  Absent
                </MenuItem>


                <MenuItem value="LEAVE">
                  Leave
                </MenuItem>


                <MenuItem value="LATE">
                  Late
                </MenuItem>


                <MenuItem value="HALF_DAY">
                  Half Day
                </MenuItem>


              </TextField>


            </Grid>




          </Grid>







          <Divider sx={{my:4}} />







          <Box

            display="flex"

            justifyContent="flex-end"

            gap={2}

          >


            <Button

              variant="outlined"

              startIcon={<ArrowBackIcon/>}

              onClick={()=>navigate("/attendance")}

            >

              Cancel

            </Button>





            <Button

              variant="contained"

              startIcon={<SaveIcon/>}

              onClick={handleUpdate}

            >

              Update Attendance

            </Button>




          </Box>







        </CardContent>


      </Card>







      <Snackbar

        open={openSnackbar}

        autoHideDuration={3000}

        onClose={()=>setOpenSnackbar(false)}

        anchorOrigin={{

          vertical:"top",

          horizontal:"right"

        }}

      >

        <Alert

          severity="success"

          variant="filled"

        >

          Attendance updated successfully!

        </Alert>


      </Snackbar>




    </PageContainer>

  );

}

export default EditAttendance;