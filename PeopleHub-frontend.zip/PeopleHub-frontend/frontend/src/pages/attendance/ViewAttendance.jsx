import  {
     useEffect,
     useState 
} from "react";
 import  {
     useNavigate,
     useParams 
} from "react-router-dom";
 import  {
     Avatar,
     Box,
     Button,
     Card,
     CardContent,
     Chip,
     CircularProgress,
     Divider,
     Paper,
     Typography,
} from "@mui/material";
 import Grid from "@mui/material/Grid";
 import attendanceService from "../../services/attendanceService";
 import PageContainer from "../../components/common/PageContainer";
 import PageHeader from "../../components/common/PageHeader";
 import ArrowBackIcon from "@mui/icons-material/ArrowBack";
 import EditIcon from "@mui/icons-material/Edit";
 import EventAvailableIcon from "@mui/icons-material/EventAvailable";
 import PersonIcon from "@mui/icons-material/Person";
 import AccessTimeIcon from "@mui/icons-material/AccessTime";
 function ViewAttendance()  {
     const  {
         id 
    } = useParams();
     const navigate = useNavigate();
     const [attendance,
     setAttendance] = useState(null);
     useEffect(() =>  {
         loadAttendance();
    },
     []);
     const loadAttendance = async () =>  {
         try  {
             const response = await attendanceService.getAttendanceById(id);
             setAttendance(response.data);
        } catch(error)  {
             console.error(error);
        } 
    };
     if(!attendance) {
         return ( <PageContainer> <Box sx= {
             {
                 height:"70vh",
                 display:"flex",
                 justifyContent:"center",
                 alignItems:"center" 
            }
        } > <CircularProgress size= {
            55
        }/> </Box> </PageContainer> );
    } const getStatusColor = () =>  {
         switch(attendance.status) {
             case "PRESENT": return "success";
             case "ABSENT": return "error";
             case "LEAVE": return "warning";
             default: return "default";
        } 
    };
     return ( <PageContainer> <PageHeader title="Attendance Details" subtitle="View complete attendance information." breadcrumbs= {
        [  {
             label:"Dashboard",
             path:"/dashboard" 
        },
          {
             label:"Attendance",
             path:"/attendance" 
        },
          {
             label:"View Attendance" 
        } ]
    } /> <Card elevation= {
        0
    } sx= {
         {
             borderRadius:4,
             border:"1px solid #E5E7EB" 
        }
    } > <CardContent sx= {
         {
            p:4
        }
    }>  {
        /* Header Section */
    } <Box display="flex" alignItems="center" gap= {
        3
    } mb= {
        4
    } > <Avatar sx= {
         {
             width:90,
             height:90,
             bgcolor:"primary.main" 
        }
    } > <EventAvailableIcon sx= {
         {
            fontSize:45
        }
    } /> </Avatar> <Box flex= {
        1
    }> <Typography variant="h4" fontWeight= {
        700
    } > Attendance Record </Typography> <Typography color="text.secondary" mt= {
        1
    } > Employee attendance summary </Typography> <Chip sx= {
         {
            mt:2
        }
    } label= {
        attendance.status
    } color= {
        getStatusColor()
    } /> </Box> </Box> <Divider sx= {
         {
            mb:4
        }
    } /> <Grid container spacing= {
        3
    } > <Grid size= {
         {
            xs:12,
            md:6
        }
    }> <Paper elevation= {
        0
    } sx= {
         {
             p:3,
             borderRadius:3,
             border:"1px solid #E5E7EB" 
        }
    } > <Box display="flex" gap= {
        2
    } > <Avatar sx= {
         {
             bgcolor:"#E3F2FD",
             color:"#1976D2" 
        }
    } > <PersonIcon/> </Avatar> <Box> <Typography color="text.secondary" fontSize= {
        14
    } > Employee </Typography> <Typography fontWeight= {
        600
    } >  {
        attendance.employeeName
    } </Typography> </Box> </Box> </Paper> </Grid> <Grid size= {
         {
            xs:12,
            md:6
        }
    }> <Paper elevation= {
        0
    } sx= {
         {
             p:3,
             borderRadius:3,
             border:"1px solid #E5E7EB" 
        }
    } > <Box display="flex" gap= {
        2
    } > <Avatar sx= {
         {
             bgcolor:"#E8F5E9",
             color:"#2E7D32" 
        }
    } > <EventAvailableIcon/> </Avatar> <Box> <Typography color="text.secondary" fontSize= {
        14
    } > Attendance Date </Typography> <Typography fontWeight= {
        600
    } >  {
        attendance.attendanceDate
    } </Typography> </Box> </Box> </Paper> </Grid> <Grid size= {
         {
            xs:12,
            md:6
        }
    }> <Paper elevation= {
        0
    } sx= {
         {
             p:3,
             borderRadius:3,
             border:"1px solid #E5E7EB" 
        }
    } > <Box display="flex" gap= {
        2
    } > <Avatar sx= {
         {
             bgcolor:"#FFF3E0",
             color:"#FB8C00" 
        }
    } > <AccessTimeIcon/> </Avatar> <Box> <Typography color="text.secondary" fontSize= {
        14
    } > Check In </Typography> <Typography fontWeight= {
        600
    } >  {
         attendance.checkIn ? new Date(attendance.checkIn) .toLocaleString() : "-" 
    } </Typography> </Box> </Box> </Paper> </Grid> <Grid size= {
         {
            xs:12,
            md:6
        }
    }> <Paper elevation= {
        0
    } sx= {
         {
             p:3,
             borderRadius:3,
             border:"1px solid #E5E7EB" 
        }
    } > <Box display="flex" gap= {
        2
    } > <Avatar sx= {
         {
             bgcolor:"#FCE4EC",
             color:"#D81B60" 
        }
    } > <AccessTimeIcon/> </Avatar> <Box> <Typography color="text.secondary" fontSize= {
        14
    } > Check Out </Typography> <Typography fontWeight= {
        600
    } >  {
         attendance.checkOut ? new Date(attendance.checkOut) .toLocaleString() : "-" 
    } </Typography> </Box> </Box> </Paper> </Grid> </Grid> <Divider sx= {
         {
            my:4
        }
    } /> <Box display="flex" justifyContent="flex-end" gap= {
        2
    } > <Button variant="outlined" startIcon= {
        <ArrowBackIcon/>
    } onClick= {
        ()=>navigate("/attendance")
    } > Back </Button> <Button variant="contained" startIcon= {
        <EditIcon/>
    } onClick= {
        ()=> navigate( `/attendance/edit/${attendance.id}` ) 
    } > Edit Attendance </Button> </Box> </CardContent> </Card> </PageContainer> );
} export default ViewAttendance;