import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import payrollService from "../../services/payrollService";

import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Divider,
  Paper,
  Typography,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import BadgeIcon from "@mui/icons-material/Badge";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import CurrencyRupeeIcon from "@mui/icons-material/CurrencyRupee";
import PaymentsIcon from "@mui/icons-material/Payments";
import SavingsIcon from "@mui/icons-material/Savings";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";

function ViewPayroll() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [payroll, setPayroll] = useState(null);

  useEffect(() => {
    loadPayroll();
  }, []);

  const loadPayroll = async () => {
    try {
      const response = await payrollService.getPayrollById(id);
      setPayroll(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  if (!payroll) {
    return (
      <PageContainer>
        <Box
          sx={{
            height: "70vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <CircularProgress size={55} />
        </Box>
      </PageContainer>
    );
  }

  const amount = (value) =>
    `₹ ${Number(value || 0).toLocaleString("en-IN")}`;

  return (
    <PageContainer>

      <PageHeader
        title="Payroll Details"
        subtitle="View complete payroll information."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Payroll",
            path: "/payroll",
          },
          {
            label: "View Payroll",
          },
        ]}
        actions={
          <Button
            variant="outlined"
            startIcon={<ArrowBackIcon />}
            onClick={() => navigate("/payroll")}
          >
            Back
          </Button>
        }
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 4 }}>

          {/* Header */}

          <Box
            display="flex"
            alignItems="center"
            gap={3}
            mb={5}
          >
            <Avatar
              sx={{
                width: 90,
                height: 90,
                bgcolor: "primary.main",
                fontSize: 32,
                fontWeight: 700,
              }}
            >
              {payroll.employeeName?.charAt(0)}
            </Avatar>

            <Box flex={1}>
              <Typography
                variant="h4"
                fontWeight={700}
              >
                {payroll.employeeName}
              </Typography>

              <Typography
                color="text.secondary"
                mt={1}
              >
                Payroll Summary
              </Typography>

              <Box
                display="flex"
                gap={2}
                mt={2}
                flexWrap="wrap"
              >
                <Chip
                  icon={<CalendarMonthIcon />}
                  label={`${payroll.month} ${payroll.year}`}
                  color="primary"
                />

                <Chip
                  icon={<BadgeIcon />}
                  label={payroll.status}
                  color={
                    payroll.status === "PAID"
                      ? "success"
                      : "warning"
                  }
                />
              </Box>
            </Box>
          </Box>

          <Divider sx={{ mb: 4 }} />

          <Grid container spacing={3}>

            {[
              {
                title: "Basic Salary",
                value: payroll.basicSalary,
                icon: <CurrencyRupeeIcon />,
              },
              {
                title: "HRA",
                value: payroll.hra,
                icon: <PaymentsIcon />,
              },
              {
                title: "Allowance",
                value: payroll.allowance,
                icon: <AccountBalanceWalletIcon />,
              },
              {
                title: "Bonus",
                value: payroll.bonus,
                icon: <SavingsIcon />,
              },
              {
                title: "Tax",
                value: payroll.tax,
                icon: <CurrencyRupeeIcon />,
              },
              {
                title: "PF",
                value: payroll.pf,
                icon: <PaymentsIcon />,
              },
              {
                title: "Deduction",
                value: payroll.deduction,
                icon: <CurrencyRupeeIcon />,
              },
              {
                title: "Gross Salary",
                value: payroll.grossSalary,
                icon: <CurrencyRupeeIcon />,
              },
            ].map((item) => (
              <Grid
                key={item.title}
                size={{ xs: 12, md: 6 }}
              >
                <Paper
                  elevation={0}
                  sx={{
                    p: 3,
                    borderRadius: 3,
                    border: "1px solid #E5E7EB",
                  }}
                >
                  <Box display="flex" gap={2}>
                    <Avatar
                      sx={{
                        bgcolor: "#E3F2FD",
                        color: "#1976D2",
                      }}
                    >
                      {item.icon}
                    </Avatar>

                    <Box>
                      <Typography
                        fontSize={14}
                        color="text.secondary"
                      >
                        {item.title}
                      </Typography>

                      <Typography
                        fontWeight={700}
                      >
                        {amount(item.value)}
                      </Typography>
                    </Box>
                  </Box>
                </Paper>
              </Grid>
            ))}

            {/* Net Salary */}

            <Grid size={12}>
              <Paper
                elevation={0}
                sx={{
                  mt: 2,
                  p: 4,
                  borderRadius: 4,
                  background:
                    "linear-gradient(135deg,#1976D2,#42A5F5)",
                  color: "#fff",
                }}
              >
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  flexWrap="wrap"
                >
                  <Box>
                    <Typography sx={{ opacity: 0.9 }}>
                      Net Salary
                    </Typography>

                    <Typography
                      variant="h3"
                      fontWeight={700}
                      mt={1}
                    >
                      {amount(payroll.netSalary)}
                    </Typography>
                  </Box>

                  <Avatar
                    sx={{
                      width: 70,
                      height: 70,
                      bgcolor: "rgba(255,255,255,.15)",
                    }}
                  >
                    <CurrencyRupeeIcon
                      sx={{
                        color: "#fff",
                        fontSize: 38,
                      }}
                    />
                  </Avatar>
                </Box>
              </Paper>
            </Grid>

          </Grid>

          <Divider sx={{ my: 4 }} />

          <Box display="flex" justifyContent="flex-end">
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate("/payroll")}
            >
              Back
            </Button>
          </Box>

        </CardContent>
      </Card>

    </PageContainer>
  );
}

export default ViewPayroll;