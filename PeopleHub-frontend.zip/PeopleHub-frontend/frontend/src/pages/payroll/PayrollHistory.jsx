import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Card,
  CardContent,
  Divider,
  InputAdornment,
  TextField,
} from "@mui/material";

import SearchIcon from "@mui/icons-material/Search";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import PayrollTable from "../../components/tables/PayrollTable";
import payrollService from "../../services/payrollService";

function PayrollHistory() {
  const navigate = useNavigate();

  const [payrolls, setPayrolls] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    loadPayrolls();
  }, []);

  const loadPayrolls = async () => {
    try {
      const response = await payrollService.getAllPayrolls();
      setPayrolls(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const filteredPayrolls = payrolls.filter((item) =>
    item.employeeName
      ?.toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <PageContainer>

      <PageHeader
        title="Payroll Management"
        subtitle="View and manage employee payroll history."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Payroll",
          },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
          overflow: "hidden",
        }}
      >
        <CardContent sx={{ p: 4 }}>

          <Box
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            flexWrap="wrap"
            gap={2}
            mb={3}
          >
            <TextField
              size="small"
              placeholder="Search employee"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
              sx={{
                width: {
                  xs: "100%",
                  sm: 320,
                },
              }}
            />
          </Box>

          <Divider sx={{ mb: 3 }} />

          <PayrollTable payrolls={filteredPayrolls} />

        </CardContent>
      </Card>

    </PageContainer>
  );
}

export default PayrollHistory;