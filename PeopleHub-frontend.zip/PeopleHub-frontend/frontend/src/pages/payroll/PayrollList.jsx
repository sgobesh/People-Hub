import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Card,
  CardContent,
  Divider,
  Typography,
} from "@mui/material";

import TablePagination from "@mui/material/TablePagination";

import PageContainer from "../../components/common/PageContainer";
import PageToolbar from "../../components/common/PageToolbar";

import PayrollTable from "../../components/tables/PayrollTable";
import payrollService from "../../services/payrollService";

function PayrollList() {
  const navigate = useNavigate();

  const [payrolls, setPayrolls] = useState([]);
  const [filteredPayrolls, setFilteredPayrolls] = useState([]);
  const [search, setSearch] = useState("");

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  useEffect(() => {
    loadPayrolls();
  }, []);

  const loadPayrolls = async () => {
    try {
      const response = await payrollService.getAllPayrolls();

      setPayrolls(response.data);
      setFilteredPayrolls(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSearch = (value) => {
    setSearch(value);

    if (value.trim() === "") {
      setFilteredPayrolls(payrolls);
      return;
    }

    const filtered = payrolls.filter((item) =>
      (
        item.employeeName ||
        item.employee?.firstName ||
        ""
      )
        .toLowerCase()
        .includes(value.toLowerCase())
    );

    setFilteredPayrolls(filtered);
    setPage(0);
  };

  const paySalary = async (id) => {
    try {
      await payrollService.paySalary(id);
      loadPayrolls();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <PageContainer>

      {/* Header */}

      <Box mb={3}>
        <PageToolbar
          buttonText="+ Generate Payroll"
          onAdd={() => navigate("/payroll/generate")}
          search={search}
          onSearch={(e) => handleSearch(e.target.value)}
        />
      </Box>

      {/* Payroll Information */}

      <Card
        elevation={0}
        sx={{
          mb: 3,
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 3 }}>

          <Typography
            fontWeight={700}
            mb={2}
          >
            Payroll Records
          </Typography>

          <Divider sx={{ mb: 3 }} />

          <PayrollTable
            payrolls={filteredPayrolls.slice(
              page * rowsPerPage,
              page * rowsPerPage + rowsPerPage
            )}
            onPay={paySalary}
          />

        </CardContent>
      </Card>

      {/* Pagination */}

      <Box
        display="flex"
        justifyContent="flex-end"
        mt={2}
      >
        <TablePagination
          component="div"
          count={filteredPayrolls.length}
          page={page}
          rowsPerPage={rowsPerPage}
          onPageChange={(event, newPage) =>
            setPage(newPage)
          }
          onRowsPerPageChange={(event) => {
            setRowsPerPage(parseInt(event.target.value, 10));
            setPage(0);
          }}
        />
      </Box>

    </PageContainer>
  );
}

export default PayrollList;