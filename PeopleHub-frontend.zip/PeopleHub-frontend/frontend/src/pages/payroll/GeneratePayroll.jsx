import { useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Button,
  Card,
  CardContent,
  Divider,
  Typography,
} from "@mui/material";

import PageContainer from "../../components/common/PageContainer";
import PageHeader from "../../components/common/PageHeader";

import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";

import PayrollForm from "../../components/forms/PayrollForm";
import payrollService from "../../services/payrollService";

function GeneratePayroll() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    employeeId: "",
    month: "",
    year: new Date().getFullYear(),
    basicSalary: 0,
    hra: 0,
    allowance: 0,
    bonus: 0,
    tax: 0,
    pf: 0,
    otherDeduction: 0,
    grossSalary: 0,
    netSalary: 0,
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await payrollService.generatePayroll(formData);

      alert("Payroll generated successfully!");

      navigate("/payroll");
    } catch (error) {
      console.error(error);

      alert(
        error.response?.data?.message ||
          "Unable to generate payroll."
      );
    }
  };

  return (
    <PageContainer>

      <PageHeader
        title="Generate Payroll"
        subtitle="Generate employee payroll for a selected month."
        breadcrumbs={[
          {
            label: "Dashboard",
            path: "/dashboard",
          },
          {
            label: "Payroll",
            path: "/payroll",
          },
          {
            label: "Generate Payroll",
          },
        ]}
      />

      <Card
        elevation={0}
        sx={{
          borderRadius: 4,
          border: "1px solid #E5E7EB",
        }}
      >
        <CardContent sx={{ p: 4 }}>

          <Typography
            variant="h6"
            fontWeight={700}
            mb={3}
          >
            Payroll Information
          </Typography>

          <Divider sx={{ mb: 4 }} />

          <Box
            component="form"
            onSubmit={handleSubmit}
          >
            <PayrollForm
              formData={formData}
              setFormData={setFormData}
            />

            <Divider sx={{ my: 4 }} />

            <Box
              display="flex"
              justifyContent="flex-end"
              gap={2}
            >
              <Button
                variant="outlined"
                startIcon={<CancelIcon />}
                onClick={() => navigate("/payroll")}
              >
                Cancel
              </Button>

              <Button
                type="submit"
                variant="contained"
                startIcon={<SaveIcon />}
              >
                Generate Payroll
              </Button>
            </Box>

          </Box>

        </CardContent>
      </Card>

    </PageContainer>
  );
}

export default GeneratePayroll;