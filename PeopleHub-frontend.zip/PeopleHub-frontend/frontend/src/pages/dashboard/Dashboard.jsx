import { useEffect, useState } from "react";
import {
  Box,
  Button,
  Card,
  CardContent,
  Grid,
  Stack,
  Typography,
} from "@mui/material";

import AddIcon from "@mui/icons-material/Add";
import PeopleIcon from "@mui/icons-material/People";
import BusinessIcon from "@mui/icons-material/Business";
import PaymentsIcon from "@mui/icons-material/Payments";
import EventNoteIcon from "@mui/icons-material/EventNote";
import WorkIcon from "@mui/icons-material/Work";
import PersonSearchIcon from "@mui/icons-material/PersonSearch";

import DashboardCard from "../../components/common/DashboardCard";
import EmployeeChart from "../../components/charts/EmployeeChart";
import dashboardService from "../../services/dashboardService";

function Dashboard() {
  const [stats, setStats] = useState({
    totalEmployees: 0,
    totalDepartments: 0,
    totalJobs: 0,
    totalCandidates: 0,
    totalPayrolls: 0,
    pendingLeaves: 0,
  });

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const response = await dashboardService.getDashboardStats();
      setStats(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      {/* Header */}
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        flexWrap="wrap"
        mb={4}
      >
        <Box>
          <Typography variant="h4" fontWeight="bold">
            Dashboard
          </Typography>

          <Typography color="text.secondary" mt={0.5}>
            Welcome back! Here's an overview of your organization.
          </Typography>
        </Box>

        <Button
          variant="contained"
          startIcon={<AddIcon />}
          sx={{
            borderRadius: 3,
            px: 3,
          }}
        >
          Quick Action
        </Button>
      </Box>

      {/* KPI Cards */}
      <Grid container spacing={3}>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <DashboardCard
            title="Employees"
            value={stats.totalEmployees}
            subtitle="Total Employees"
            icon={<PeopleIcon fontSize="large" />}
            color="#1976D2"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <DashboardCard
            title="Departments"
            value={stats.totalDepartments}
            subtitle="Departments"
            icon={<BusinessIcon fontSize="large" />}
            color="#2E7D32"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <DashboardCard
            title="Jobs"
            value={stats.totalJobs}
            subtitle="Open Jobs"
            icon={<WorkIcon fontSize="large" />}
            color="#1565C0"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <DashboardCard
            title="Candidates"
            value={stats.totalCandidates}
            subtitle="Applications"
            icon={<PersonSearchIcon fontSize="large" />}
            color="#8E24AA"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, lg: 6 }}>
          <DashboardCard
            title="Payroll"
            value={stats.totalPayrolls}
            subtitle="Payroll Records"
            icon={<PaymentsIcon fontSize="large" />}
            color="#9C27B0"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, lg: 6 }}>
          <DashboardCard
            title="Pending Leaves"
            value={stats.pendingLeaves}
            subtitle="Awaiting Approval"
            icon={<EventNoteIcon fontSize="large" />}
            color="#F57C00"
          />
        </Grid>
      </Grid>

      {/* Chart + Quick Actions */}
      <Grid container spacing={3} mt={1}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <EmployeeChart />
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{ height: "100%", borderRadius: 4 }}>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" mb={3}>
                Quick Actions
              </Typography>

              <Stack spacing={2}>
                <Button variant="contained" fullWidth>
                  Add Employee
                </Button>

                <Button variant="outlined" fullWidth>
                  Add Department
                </Button>

                <Button variant="outlined" fullWidth>
                  Post Job
                </Button>

                <Button variant="outlined" fullWidth>
                  Apply Leave
                </Button>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Bottom Section */}
      <Grid container spacing={3} mt={1}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card sx={{ borderRadius: 4 }}>
            <CardContent>
              <Typography variant="h6" fontWeight="bold">
                Recent Employees
              </Typography>

              <Typography color="text.secondary" mt={2}>
                Employee table will be displayed here.
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{ borderRadius: 4 }}>
            <CardContent>
              <Typography variant="h6" fontWeight="bold">
                Notifications
              </Typography>

              <Typography color="text.secondary" mt={2}>
                Latest notifications will appear here.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </>
  );
}

export default Dashboard;