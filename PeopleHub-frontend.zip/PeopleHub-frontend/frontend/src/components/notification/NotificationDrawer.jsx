import { useEffect, useState } from "react";

import {
  Drawer,
  Box,
  Typography,
  List,
  Divider,
  IconButton,
  CircularProgress,
} from "@mui/material";

import CloseIcon from "@mui/icons-material/Close";

import NotificationItem from "./NotificationItem";

import notificationService from "../../services/notificationService";

function NotificationDrawer({

  open,

  onClose,

  refreshCount,

}) {

  const [notifications, setNotifications] = useState([]);

  const [loading, setLoading] = useState(false);

  useEffect(() => {

    if (open) {

      loadNotifications();

    }

  }, [open]);

  const loadNotifications = async () => {

    try {

      setLoading(true);

      const response =
        await notificationService.getAllNotifications();

      setNotifications(response.data);

    } catch (error) {

      console.error(error);

    } finally {

      setLoading(false);

    }

  };

  const refresh = () => {

    loadNotifications();

    refreshCount();

  };

  return (

    <Drawer

      anchor="right"

      open={open}

      onClose={onClose}

    >

      <Box

        sx={{

          width: 380,

          p: 2,

        }}

      >

        <Box

          display="flex"

          justifyContent="space-between"

          alignItems="center"

        >

          <Typography

            variant="h6"

            fontWeight="bold"

          >

            Notifications

          </Typography>

          <IconButton

            onClick={onClose}

          >

            <CloseIcon />

          </IconButton>

        </Box>

        <Divider sx={{ my: 2 }} />

        {loading ? (

          <Box

            display="flex"

            justifyContent="center"

            mt={5}

          >

            <CircularProgress />

          </Box>

        ) : notifications.length === 0 ? (

          <Typography

            align="center"

            color="text.secondary"

            mt={5}

          >

            No Notifications Found

          </Typography>

        ) : (

          <List>

            {notifications.map((notification) => (

              <NotificationItem

                key={notification.id}

                notification={notification}

                refresh={refresh}

              />

            ))}

          </List>

        )}

      </Box>

    </Drawer>

  );

}

export default NotificationDrawer;