import {
  ListItem,
  ListItemText,
  Typography,
  Chip,
  Stack,
  IconButton,
} from "@mui/material";

import DoneIcon from "@mui/icons-material/Done";
import DeleteIcon from "@mui/icons-material/Delete";

import notificationService from "../../services/notificationService";

function NotificationItem({

  notification,

  refresh,

}) {

  const markAsRead = async () => {

    try {

      await notificationService.markAsRead(notification.id);

      refresh();

    } catch (error) {

      console.error(error);

    }

  };

  const deleteNotification = async () => {

    try {

      await notificationService.deleteNotification(notification.id);

      refresh();

    } catch (error) {

      console.error(error);

    }

  };

  const getChipColor = () => {

    switch (notification.type) {

      case "EMPLOYEE":
        return "primary";

      case "JOB":
        return "success";

      case "CANDIDATE":
        return "warning";

      case "LEAVE":
        return "secondary";

      case "PAYROLL":
        return "info";

      default:
        return "default";

    }

  };

  return (

    <ListItem
      divider
      alignItems="flex-start"
      sx={{
        bgcolor: notification.isRead ? "inherit" : "#F5F9FF",
        borderRadius: 2,
        mb: 1,
      }}
    >

      <ListItemText

        primary={

          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
          >

            <Typography
              fontWeight={
                notification.isRead ? 500 : 700
              }
            >

              {notification.title}

            </Typography>

            <Chip

              label={notification.type}

              size="small"

              color={getChipColor()}

            />

          </Stack>

        }

        secondary={

          <>

            <Typography
              variant="body2"
              sx={{ mt: 1 }}
            >

              {notification.message}

            </Typography>

           <Typography
  variant="caption"
  color="text.secondary"
>
  {notification.createdAt
    ? new Date(notification.createdAt).toLocaleString()
    : "Just now"}
</Typography>

          </>

        }

      />

      <Stack>

        {!notification.isRead && (

          <IconButton

            color="success"

            onClick={markAsRead}

          >

            <DoneIcon />

          </IconButton>

        )}

        <IconButton

          color="error"

          onClick={deleteNotification}

        >

          <DeleteIcon />

        </IconButton>

      </Stack>

    </ListItem>

  );

}

export default NotificationItem;