import { useEffect, useState } from "react";

import {
  Badge,
  IconButton,
} from "@mui/material";

import NotificationsIcon from "@mui/icons-material/Notifications";

import NotificationDrawer from "./NotificationDrawer";

import notificationService from "../../services/notificationService";

function NotificationBell() {

  const [open, setOpen] = useState(false);

  const [count, setCount] = useState(0);

  useEffect(() => {
  loadUnreadNotifications();
}, []);

  const loadUnreadNotifications = async () => {

    try {

      const response =
    await notificationService.getUnreadCount();

setCount(response.data);

    } catch (error) {

      console.error(error);

    }

  };

  return (

    <>

      <IconButton
        color="inherit"
        onClick={() => setOpen(true)}
      >

        <Badge
          badgeContent={count}
          color="error"
        >

          <NotificationsIcon />

        </Badge>

      </IconButton>

      <NotificationDrawer
        open={open}
        onClose={() => setOpen(false)}
        refreshCount={loadUnreadNotifications}
      />

    </>

  );

}

export default NotificationBell;