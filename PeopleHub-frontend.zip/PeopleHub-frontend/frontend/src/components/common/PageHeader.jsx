import { Box, Typography, Button } from "@mui/material";

function PageHeader({
  title,
  subtitle,
  buttonText,
  buttonIcon,
  onButtonClick,
}) {
  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        mb: 3,
        flexWrap: "wrap",
        gap: 2,
      }}
    >
      <Box>
        <Typography
          variant="h4"
          fontWeight={700}
        >
          {title}
        </Typography>

        <Typography
          color="text.secondary"
          mt={0.5}
        >
          {subtitle}
        </Typography>
      </Box>

      {buttonText && (
        <Button
          variant="contained"
          startIcon={buttonIcon}
          onClick={onButtonClick}
          sx={{
            borderRadius: 3,
            px: 3,
          }}
        >
          {buttonText}
        </Button>
      )}
    </Box>
  );
}

export default PageHeader;