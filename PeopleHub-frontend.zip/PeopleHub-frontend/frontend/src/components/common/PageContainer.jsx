import { Box, Paper } from "@mui/material";

function PageContainer({ children }) {
  return (
    <Paper
      elevation={0}
      sx={{
        p: 3,
        borderRadius: 4,
        border: "1px solid #E5E7EB",
        bgcolor: "#fff",
      }}
    >
      {children}
    </Paper>
  );
}

export default PageContainer;