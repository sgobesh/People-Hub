import {
  Box,
  Button,
  TextField,
  InputAdornment,
} from "@mui/material";

import SearchRoundedIcon from "@mui/icons-material/SearchRounded";

function PageToolbar({
  buttonText,
  onAdd,
  search,
  onSearch,
}) {
  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "space-between",
        mb: 3,
        gap: 2,
        flexWrap: "wrap",
      }}
    >
      <Button
        variant="contained"
        onClick={onAdd}
        sx={{
          borderRadius: 2,
          textTransform: "none",
          px: 3,
        }}
      >
        {buttonText}
      </Button>

      <TextField
        size="small"
        value={search}
        onChange={onSearch}
        placeholder="Search..."
        sx={{
          width: 320,
        }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchRoundedIcon />
            </InputAdornment>
          ),
        }}
      />
    </Box>
  );
}

export default PageToolbar;