import { Card } from "@mui/material";

function PageCard({ children }) {
  return (
    <Card
      sx={{
        p: 3,
        borderRadius: 4,
        boxShadow: "0 8px 24px rgba(0,0,0,.08)",
      }}
    >
      {children}
    </Card>
  );
}

export default PageCard;