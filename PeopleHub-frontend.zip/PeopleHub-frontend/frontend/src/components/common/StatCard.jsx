import {
  Card,
  CardContent,
  Typography,
  Box,
} from "@mui/material";

function StatCard({
  title,
  value,
  icon,
  color,
}) {
  return (
    <Card
      sx={{
        borderRadius: 4,
        transition: ".3s",
        cursor: "pointer",

        "&:hover": {
          transform: "translateY(-5px)",
        },
      }}
    >
      <CardContent>

        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
        >
          <Box>

            <Typography
              color="text.secondary"
            >
              {title}
            </Typography>

            <Typography
              variant="h4"
              fontWeight={700}
            >
              {value}
            </Typography>

          </Box>

          <Box
            sx={{
              bgcolor: color,
              color: "#fff",
              p: 2,
              borderRadius: 3,
            }}
          >
            {icon}
          </Box>

        </Box>

      </CardContent>
    </Card>
  );
}

export default StatCard;