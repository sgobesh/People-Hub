import {
  Paper,
  InputBase,
  IconButton,
} from "@mui/material";

import SearchIcon from "@mui/icons-material/Search";

function SearchToolbar({
  value,
  onChange,
  placeholder = "Search...",
}) {
  return (
    <Paper
      elevation={0}
      sx={{
        display: "flex",
        alignItems: "center",
        mb: 3,
        px: 2,
        py: 1,
        borderRadius: 3,
        border: "1px solid #ddd",
      }}
    >
      <SearchIcon color="action" />

      <InputBase
        sx={{
          ml: 2,
          flex: 1,
        }}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
      />

      <IconButton>
        <SearchIcon />
      </IconButton>
    </Paper>
  );
}

export default SearchToolbar;