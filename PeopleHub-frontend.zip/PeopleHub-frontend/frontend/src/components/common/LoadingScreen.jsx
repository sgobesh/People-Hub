import {
  Box,
  CircularProgress,
} from "@mui/material";

function LoadingScreen() {
  return (
    <Box
      display="flex"
      justifyContent="center"
      alignItems="center"
      minHeight="60vh"
    >
      <CircularProgress />
    </Box>
  );
}

export default LoadingScreen;