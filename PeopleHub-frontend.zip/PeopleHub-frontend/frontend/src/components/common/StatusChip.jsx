import { Chip } from "@mui/material";

function StatusChip({
  label,
  color = "primary",
}) {
  return (
    <Chip
      label={label}
      color={color}
      sx={{
        fontWeight: 600,
        borderRadius: 2,
      }}
    />
  );
}

export default StatusChip;