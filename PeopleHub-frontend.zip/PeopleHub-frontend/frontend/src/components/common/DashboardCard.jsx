import {
  Card,
  CardContent,
  Typography,
  Box,
  Avatar,
  Chip,
} from "@mui/material";

import TrendingUpIcon from "@mui/icons-material/TrendingUp";

function DashboardCard({
  title,
  value,
  subtitle,
  icon,
  color = "#1976d2",
}) {
  return (
    <Card
      elevation={0}
      sx={{
        height: "100%",
        minHeight: 210,
        borderRadius: 4,
        border: "1px solid #E6EAF2",
        overflow: "hidden",
        transition: "all .3s ease",

        "&:hover": {
          transform: "translateY(-5px)",
          boxShadow: "0 12px 30px rgba(0,0,0,.08)",
        },
      }}
    >
      {/* Top Color Line */}
      <Box
        sx={{
          height: 5,
          bgcolor: color,
        }}
      />

      <CardContent
        sx={{
          p: 3,
          display: "flex",
          flexDirection: "column",
          height: "100%",
        }}
      >
        {/* Header */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
        >
          <Typography
            sx={{
              fontSize: 15,
              fontWeight: 600,
              color: "#666",
            }}
          >
            {title}
          </Typography>

          <Avatar
            sx={{
              bgcolor: color,
              width: 52,
              height: 52,

              "& svg": {
                fontSize: 28,
              },
            }}
          >
            {icon}
          </Avatar>
        </Box>

        {/* Value */}
        <Typography
          sx={{
            mt: 3,
            fontSize: 38,
            fontWeight: 700,
            color: "#222",
            lineHeight: 1,
          }}
        >
          {value ?? 0}
        </Typography>

        {/* Subtitle */}
        <Typography
          sx={{
            mt: 1,
            color: "#777",
            fontSize: 15,
          }}
        >
          {subtitle}
        </Typography>

        <Box sx={{ flexGrow: 1 }} />

        {/* Footer */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mt={3}
        >
          <Chip
            size="small"
            icon={<TrendingUpIcon />}
            label="Live"
            color="success"
            sx={{
              fontWeight: 600,
              borderRadius: 2,
            }}
          />

          <Typography
            variant="caption"
            color="text.secondary"
          >
            Updated now
          </Typography>
        </Box>
      </CardContent>
    </Card>
  );
}

export default DashboardCard;