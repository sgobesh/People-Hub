import {
  Box,
  Drawer,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Tooltip,
  Divider,
} from "@mui/material";

import { Link, useLocation, useNavigate } from "react-router-dom";

import DashboardRoundedIcon from "@mui/icons-material/DashboardRounded";
import PeopleRoundedIcon from "@mui/icons-material/PeopleRounded";
import BusinessRoundedIcon from "@mui/icons-material/BusinessRounded";
import PaymentsRoundedIcon from "@mui/icons-material/PaymentsRounded";
import EventNoteRoundedIcon from "@mui/icons-material/EventNoteRounded";
import SmartToyRoundedIcon from "@mui/icons-material/SmartToyRounded";
import SettingsRoundedIcon from "@mui/icons-material/SettingsRounded";
import LogoutRoundedIcon from "@mui/icons-material/LogoutRounded";
import AccessTimeRoundedIcon from "@mui/icons-material/AccessTimeRounded";
import WorkRoundedIcon from "@mui/icons-material/WorkRounded";
import PersonSearchRoundedIcon from "@mui/icons-material/PersonSearchRounded";
import NotificationsRoundedIcon from "@mui/icons-material/NotificationsRounded";

import {
  DRAWER_WIDTH,
  MINI_DRAWER_WIDTH,
} from "./MainLayout";

const menuItems = [
  {
    text: "Dashboard",
    icon: <DashboardRoundedIcon />,
    path: "/dashboard",
  },
  {
    text: "Employees",
    icon: <PeopleRoundedIcon />,
    path: "/employees",
  },
  {
    text: "Attendance",
    icon: <AccessTimeRoundedIcon />,
    path: "/attendance",
  },
  {
    text: "Departments",
    icon: <BusinessRoundedIcon />,
    path: "/departments",
  },
  {
    text: "Payroll",
    icon: <PaymentsRoundedIcon />,
    path: "/payroll",
  },
  {
    text: "Notifications",
    icon: <NotificationsRoundedIcon />,
    path: "/notifications",
  },
  {
    text: "Leave",
    icon: <EventNoteRoundedIcon />,
    path: "/leave",
  },
  {
    text: "Jobs",
    icon: <WorkRoundedIcon />,
    path: "/jobs",
  },
  {
    text: "Recruitment",
    icon: <DashboardRoundedIcon />,
    path: "/recruitment",
  },
  {
    text: "Candidates",
    icon: <PersonSearchRoundedIcon />,
    path: "/candidates",
  },
  {
    text: "AI Assistant",
    icon: <SmartToyRoundedIcon />,
    path: "/ai",
  },
  {
    text: "Settings",
    icon: <SettingsRoundedIcon />,
    path: "/settings",
  },
];

function Sidebar({ sidebarOpen }) {
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/", { replace: true });
  };

  return (
    <Drawer
  variant="persistent"
  open={open}
      sx={{
        width: sidebarOpen
          ? DRAWER_WIDTH
          : MINI_DRAWER_WIDTH,

        flexShrink: 0,

        "& .MuiDrawer-paper": {
          width: sidebarOpen
            ? DRAWER_WIDTH
            : MINI_DRAWER_WIDTH,

          transition: "all .3s ease",

          overflowX: "hidden",

          borderRight: "1px solid #E8ECF3",

          bgcolor: "#fff",

          boxSizing: "border-box",
        },
      }}
    >
      <Toolbar />

      {/* Logo */}

      <Box
        sx={{
          py: 3,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Typography
          variant="h5"
          fontWeight={800}
          color="primary"
        >
          {sidebarOpen ? "AI-HRMS" : "AI"}
        </Typography>
      </Box>

      <Divider />

      {/* Menu */}

      <Box
        sx={{
          flex: 1,
          overflowY: "auto",
          py: 1,
        }}
      >
        <List>

          {menuItems.map((item) => (

            <Tooltip
              key={item.text}
              title={!sidebarOpen ? item.text : ""}
              placement="right"
            >

              <ListItemButton
                component={Link}
                to={item.path}
                selected={location.pathname === item.path}

                sx={{
                  mx: 1.2,
                  mb: .8,

                  borderRadius: 3,

                  minHeight: 50,

                  justifyContent: sidebarOpen
                    ? "initial"
                    : "center",

                  px: 2,

                  transition: ".25s",

                  "&.Mui-selected": {

                    bgcolor: "#1976d2",

                    color: "#fff",

                    "& .MuiListItemIcon-root": {
                      color: "#fff",
                    },

                    "&:hover": {
                      bgcolor: "#1565C0",
                    },
                  },

                  "&:hover": {

                    bgcolor: "#EDF4FF",

                    "& .MuiListItemIcon-root": {
                      color: "#1976d2",
                    },
                  },
                }}
              >

                <ListItemIcon
                  sx={{
                    color: "#666",

                    minWidth: 0,

                    mr: sidebarOpen ? 2 : "auto",

                    justifyContent: "center",
                  }}
                >
                  {item.icon}
                </ListItemIcon>

                <ListItemText
                  primary={item.text}
                  sx={{
                    opacity: sidebarOpen ? 1 : 0,
                  }}
                />

              </ListItemButton>

            </Tooltip>

          ))}

        </List>
      </Box>

      <Divider />

      {/* Logout */}

      <Box sx={{ p: 1 }}>

        <Tooltip
          title={!sidebarOpen ? "Logout" : ""}
          placement="right"
        >

          <ListItemButton
            onClick={handleLogout}
            sx={{
              borderRadius: 3,
              minHeight: 50,

              justifyContent: sidebarOpen
                ? "initial"
                : "center",

              "&:hover": {
                bgcolor: "#FDECEC",
                color: "#D32F2F",
              },
            }}
          >

            <ListItemIcon
              sx={{
                minWidth: 0,

                mr: sidebarOpen ? 2 : "auto",

                justifyContent: "center",

                color: "inherit",
              }}
            >
              <LogoutRoundedIcon />
            </ListItemIcon>

            <ListItemText
              primary="Logout"
              sx={{
                opacity: sidebarOpen ? 1 : 0,
              }}
            />

          </ListItemButton>

        </Tooltip>

      </Box>

    </Drawer>
  );
}

export default Sidebar;