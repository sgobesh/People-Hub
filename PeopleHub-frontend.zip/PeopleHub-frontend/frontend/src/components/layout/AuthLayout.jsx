import { Box, Grid, Typography } from "@mui/material";

function AuthLayout({ children }) {
  return (
    <Grid container sx={{ minHeight: "100vh" }}>
      {/* Left Panel */}
      <Grid
        item
        xs={12}
        md={6}
        sx={{
          background: "linear-gradient(135deg,#1976D2,#42A5F5)",
          color: "#fff",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          p: 5,
        }}
      >
        <Typography variant="h3" fontWeight="bold">
          AI-HRMS
        </Typography>

        <Typography sx={{ mt: 2 }}>
          AI Powered Human Resource Management System
        </Typography>

        <Box sx={{ mt: 5 }}>
          <Typography>✔ Employee Management</Typography>
          <Typography>✔ Department Management</Typography>
          <Typography>✔ Payroll Management</Typography>
          <Typography>✔ AI Insights</Typography>
          <Typography>✔ Secure Authentication</Typography>
        </Box>
      </Grid>

      {/* Right Panel */}
      <Grid
        item
        xs={12}
        md={6}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          p: 3,
          bgcolor: "#F5F7FA",
        }}
      >
        {children}
      </Grid>
    </Grid>
  );
}

export default AuthLayout;
