import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

import {
  AppBar,
  Toolbar,
  Typography,
  Avatar,
  Box,
  IconButton,
  Badge,
  Menu,
  MenuItem,
  Divider,
  ListItemIcon,
} from "@mui/material";


import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
import NotificationsNoneRoundedIcon from "@mui/icons-material/NotificationsNoneRounded";
import KeyboardArrowDownRoundedIcon from "@mui/icons-material/KeyboardArrowDownRounded";

import PersonIcon from "@mui/icons-material/Person";
import LockIcon from "@mui/icons-material/Lock";
import LogoutIcon from "@mui/icons-material/Logout";


import {
  DRAWER_WIDTH,
  MINI_DRAWER_WIDTH,
} from "./MainLayout";



function Navbar({ sidebarOpen, toggleSidebar }) {


  const location = useLocation();
  const navigate = useNavigate();



  const pageTitles = {

    "/dashboard": "Dashboard",
    "/employees": "Employee Management",
    "/departments": "Department Management",
    "/attendance": "Attendance",
    "/payroll": "Payroll Management",
    "/leave": "Leave Management",
    "/jobs": "Job Management",
    "/recruitment": "Recruitment Dashboard",
    "/candidates": "Candidate Management",
    "/notifications": "Notifications",
    "/settings": "Settings",
    "/ai": "AI Assistant",

  };



  const pageTitle =
    pageTitles[location.pathname] || "AI-HRMS";





  const [anchorEl,setAnchorEl] = useState(null);



  const menuOpen = Boolean(anchorEl);





  const handleMenu = (event)=>{


    if(menuOpen){

      setAnchorEl(null);

    }
    else{

      setAnchorEl(event.currentTarget);

    }


  };





  const closeMenu = ()=>{

    setAnchorEl(null);

  };






  const goToProfile = ()=>{

    navigate("/settings?tab=profile");

    closeMenu();

  };






  const goToPassword = ()=>{

    navigate("/settings?tab=password");

    closeMenu();

  };







  const handleNotification = ()=>{

    navigate("/notifications");

  };






  const handleLogout = ()=>{


    localStorage.removeItem("token");

    localStorage.removeItem("user");


    navigate("/login");


    closeMenu();


  };








  return (


    <AppBar


      position="fixed"


      elevation={0}



      sx={{



        bgcolor:"#fff",


        color:"#1E293B",



        borderBottom:"1px solid #E8ECF3",




        width: sidebarOpen

          ? `calc(100% - ${DRAWER_WIDTH}px)`

          : `calc(100% - ${MINI_DRAWER_WIDTH}px)`,




        ml: sidebarOpen

          ? `${DRAWER_WIDTH}px`

          : `${MINI_DRAWER_WIDTH}px`,




        transition:"all .3s ease",




        boxShadow:"0 2px 12px rgba(0,0,0,.04)",




        zIndex:(theme)=>theme.zIndex.drawer+1,



      }}



    >





      <Toolbar


        sx={{


          minHeight:"70px !important",


          px:3,


        }}



      >






        {/* Sidebar Toggle */}


        <IconButton


          onClick={toggleSidebar}



          sx={{


            mr:2,



            bgcolor:"#F3F6FB",



            borderRadius:2,



            "&:hover":{


              bgcolor:"#1976d2",


              color:"#fff",


            }



          }}



        >


          <MenuRoundedIcon/>


        </IconButton>









        {/* Page Title */}



        <Typography


          variant="h5"



          sx={{


            fontWeight:700,


          }}



        >


          {pageTitle}



        </Typography>







        <Box sx={{flexGrow:1}} />








        {/* Notification */}





        <IconButton


          onClick={handleNotification}



          sx={{



            mr:2,



            bgcolor:"#F5F7FB",



            borderRadius:2,



          }}



        >



          <Badge


            badgeContent={5}


            color="error"


          >


            <NotificationsNoneRoundedIcon/>


          </Badge>




        </IconButton>









        {/* Profile Section */}




        <Box


          onClick={handleMenu}



          sx={{



            display:"flex",



            alignItems:"center",



            cursor:"pointer",



            px:1.5,



            py:.8,



            borderRadius:3,



            "&:hover":{


              bgcolor:"#F5F7FB",


            }



          }}



        >






          <Avatar


            sx={{



              bgcolor:"#1976d2",



              width:42,



              height:42,



            }}



          >



            A



          </Avatar>







          <Box sx={{ml:1.5}}>





            <Typography


              fontWeight={700}


              fontSize={14}



            >



              Administrator



            </Typography>







            <Typography


              fontSize={12}


              color="text.secondary"



            >



              HR Manager



            </Typography>






          </Box>








          <KeyboardArrowDownRoundedIcon


            sx={{ml:1}}



          />




        </Box>









        {/* Profile Menu */}





        <Menu



          anchorEl={anchorEl}



          open={menuOpen}



          onClose={closeMenu}






          anchorOrigin={{



            vertical:"bottom",



            horizontal:"right",



          }}






          transformOrigin={{



            vertical:"top",



            horizontal:"right",



          }}






          PaperProps={{



            sx:{



              mt:1,



              minWidth:220,



              borderRadius:3,



            }



          }}



        >






          <MenuItem onClick={goToProfile}>


            <ListItemIcon>


              <PersonIcon fontSize="small"/>


            </ListItemIcon>



            My Profile



          </MenuItem>









          <MenuItem onClick={goToPassword}>


            <ListItemIcon>


              <LockIcon fontSize="small"/>


            </ListItemIcon>



            Change Password



          </MenuItem>








          <Divider />









          <MenuItem onClick={handleLogout}>


            <ListItemIcon>



              <LogoutIcon


                fontSize="small"


                color="error"



              />



            </ListItemIcon>





            <Typography color="error">


              Logout



            </Typography>





          </MenuItem>







        </Menu>







      </Toolbar>





    </AppBar>


  );

}


export default Navbar;