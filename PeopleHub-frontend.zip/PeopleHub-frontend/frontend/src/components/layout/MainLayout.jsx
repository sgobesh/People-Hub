import { Box, Toolbar } from "@mui/material";
import { Outlet } from "react-router-dom";
import { useState } from "react";

import Navbar from "./Navbar";
import Sidebar from "./Sidebar";

export const DRAWER_WIDTH = 250;
export const MINI_DRAWER_WIDTH = 72;

function MainLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setSidebarOpen((prev) => !prev);
  };

  return (
    <Box
      sx={{
        display: "flex",
        minHeight: "100vh",
        bgcolor: "#F4F7FC",
      }}
    >
      <Navbar
        sidebarOpen={sidebarOpen}
        toggleSidebar={toggleSidebar}
      />

      <Sidebar
        sidebarOpen={sidebarOpen}
      />

      <Box
        component="main"
        sx={{
          flexGrow: 1,

         

          width: sidebarOpen
            ? `calc(100% - ${DRAWER_WIDTH}px)`
            : `calc(100% - ${MINI_DRAWER_WIDTH}px)`,

          transition: "all .30s ease",

          minHeight: "100vh",

          bgcolor: "#F4F7FC",

          p: 3,
        }}
      >
        <Toolbar />

        <Outlet />
      </Box>
    </Box>
  );
}

export default MainLayout;