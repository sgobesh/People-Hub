import { useEffect, useState } from "react";
import {
  Grid,
  TextField,
  MenuItem,
  Typography,
  Divider,
  Paper,
  InputAdornment,
} from "@mui/material";

import employeeService from "../../services/employeeService";

function PayrollForm({ formData, setFormData }) {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    try {
      const response = await employeeService.getAllEmployees();
      setEmployees(response.data.content || response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    let updated = {
      ...formData,
      [name]: value,
    };

    if (name === "employeeId") {
      const emp = employees.find(
        (employee) => employee.id === Number(value)
      );

      if (emp) {
        updated.basicSalary = emp.salary || 0;
      }
    }

    const basic = Number(updated.basicSalary || 0);
    const hra = Number(updated.hra || 0);
    const allowance = Number(updated.allowance || 0);
    const bonus = Number(updated.bonus || 0);
    const tax = Number(updated.tax || 0);
    const pf = Number(updated.pf || 0);
    const deduction = Number(updated.deduction || 0);

    updated.grossSalary =
      basic +
      hra +
      allowance +
      bonus;

    updated.netSalary =
      updated.grossSalary -
      tax -
      pf -
      deduction;

    setFormData(updated);
  };

  return (
    <Paper
      elevation={0}
      sx={{
        p: 4,
        borderRadius: 4,
        border: "1px solid #ECEFF5",
      }}
    >
      <Typography
        variant="h6"
        fontWeight={700}
        mb={1}
      >
        Payroll Information
      </Typography>

      <Typography
        color="text.secondary"
        mb={3}
      >
        Enter payroll details for the selected employee.
      </Typography>

      <Divider sx={{ mb: 4 }} />

      <Grid container spacing={3}>

        <Grid size={{ xs: 12, md: 6 }}>
          <TextField
            select
            fullWidth
            label="Employee"
            name="employeeId"
            value={formData.employeeId}
            onChange={handleChange}
          >
            {employees.map((employee) => (
              <MenuItem
                key={employee.id}
                value={employee.id}
              >
                {employee.firstName} {employee.lastName}
              </MenuItem>
            ))}
          </TextField>
        </Grid>

        <Grid size={{ xs: 12, md: 3 }}>
          <TextField
            select
            fullWidth
            label="Month"
            name="month"
            value={formData.month}
            onChange={handleChange}
          >
            {[
              "January",
              "February",
              "March",
              "April",
              "May",
              "June",
              "July",
              "August",
              "September",
              "October",
              "November",
              "December",
            ].map((month) => (
              <MenuItem
                key={month}
                value={month}
              >
                {month}
              </MenuItem>
            ))}
          </TextField>
        </Grid>

        <Grid size={{ xs: 12, md: 3 }}>
          <TextField
            fullWidth
            type="number"
            label="Year"
            name="year"
            value={formData.year}
            onChange={handleChange}
          />
        </Grid>

        <Grid size={12}>
          <Divider />
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <TextField
            fullWidth
            label="Basic Salary"
            value={formData.basicSalary}
            InputProps={{
              readOnly: true,
              startAdornment: (
                <InputAdornment position="start">
                  ₹
                </InputAdornment>
              ),
            }}
            sx={{
              "& .MuiInputBase-root": {
                bgcolor: "#F8FAFC",
              },
            }}
          />
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <TextField
            fullWidth
            label="HRA"
            name="hra"
            type="number"
            value={formData.hra}
            onChange={handleChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  ₹
                </InputAdornment>
              ),
            }}
          />
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <TextField
            fullWidth
            label="Allowance"
            name="allowance"
            type="number"
            value={formData.allowance}
            onChange={handleChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  ₹
                </InputAdornment>
              ),
            }}
          />
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <TextField
            fullWidth
            label="Bonus"
            name="bonus"
            type="number"
            value={formData.bonus}
            onChange={handleChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  ₹
                </InputAdornment>
              ),
            }}
          />
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <TextField
            fullWidth
            label="Tax"
            name="tax"
            type="number"
            value={formData.tax}
            onChange={handleChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  ₹
                </InputAdornment>
              ),
            }}
          />
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <TextField
            fullWidth
            label="PF"
            name="pf"
            type="number"
            value={formData.pf}
            onChange={handleChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  ₹
                </InputAdornment>
              ),
            }}
          />
        </Grid>

        <Grid size={12}>
          <TextField
            fullWidth
            label="Other Deduction"
            name="deduction"
            type="number"
            value={formData.deduction}
            onChange={handleChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  ₹
                </InputAdornment>
              ),
            }}
          />
        </Grid>

        <Grid size={12}>
          <Divider />
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <TextField
            fullWidth
            label="Gross Salary"
            value={formData.grossSalary}
            InputProps={{
              readOnly: true,
              startAdornment: (
                <InputAdornment position="start">
                  ₹
                </InputAdornment>
              ),
            }}
            sx={{
              "& .MuiInputBase-root": {
                bgcolor: "#E8F5E9",
                fontWeight: 700,
              },
            }}
          />
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <TextField
            fullWidth
            label="Net Salary"
            value={formData.netSalary}
            InputProps={{
              readOnly: true,
              startAdornment: (
                <InputAdornment position="start">
                  ₹
                </InputAdornment>
              ),
            }}
            sx={{
              "& .MuiInputBase-root": {
                bgcolor: "#E3F2FD",
                fontWeight: 700,
              },
            }}
          />
        </Grid>

      </Grid>
    </Paper>
  );
}

export default PayrollForm;