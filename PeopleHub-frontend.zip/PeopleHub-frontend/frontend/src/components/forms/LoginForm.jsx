import { useState } from "react";
import { useNavigate } from "react-router-dom";
import authService from "../../services/authService";

import {
  Box,
  Button,
  Checkbox,
  FormControl,
  FormControlLabel,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  TextField,
  Typography,
  Divider,
  CircularProgress,
} from "@mui/material";

import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import LoginRoundedIcon from "@mui/icons-material/LoginRounded";
import LockPersonRoundedIcon from "@mui/icons-material/LockPersonRounded";

function LoginForm() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);

  const [errors, setErrors] = useState({
    email: "",
    password: "",
  });

  const validate = () => {
    let valid = true;

    const newErrors = {
      email: "",
      password: "",
    };

    if (!email.trim()) {
      newErrors.email = "Email is required";
      valid = false;
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(email)
    ) {
      newErrors.email = "Enter a valid email";
      valid = false;
    }

    if (!password) {
      newErrors.password = "Password is required";
      valid = false;
    } else if (password.length < 8) {
      newErrors.password =
        "Password must contain at least 8 characters";
      valid = false;
    }

    setErrors(newErrors);

    return valid;
  };

  const handleLogin = async () => {
    if (!validate()) return;

    setLoading(true);

    try {
      const response = await authService.login({
        email,
        password,
      });

      localStorage.setItem("token", response.data.token);
      localStorage.setItem(
        "user",
        JSON.stringify(response.data)
      );

      navigate("/dashboard");
    } catch (error) {
      alert(
        error.response?.data?.message ||
          "Invalid Email or Password"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box>

      <Box textAlign="center" mb={4}>
        <LockPersonRoundedIcon
          color="primary"
          sx={{
            fontSize: 60,
            mb: 1,
          }}
        />

        <Typography
          variant="h4"
          fontWeight={700}
        >
          Welcome Back
        </Typography>

        <Typography
          color="text.secondary"
          mt={1}
        >
          Sign in to continue to PeopleHub
        </Typography>
      </Box>

      <TextField
        fullWidth
        label="Email Address"
        placeholder="Enter your email"
        value={email}
        onChange={(e) =>
          setEmail(e.target.value)
        }
        error={Boolean(errors.email)}
        helperText={errors.email}
        margin="normal"
      />

      <FormControl
        fullWidth
        margin="normal"
        error={Boolean(errors.password)}
      >
        <InputLabel>Password</InputLabel>

        <OutlinedInput
          label="Password"
          type={
            showPassword
              ? "text"
              : "password"
          }
          value={password}
          onChange={(e) =>
            setPassword(e.target.value)
          }
          endAdornment={
            <InputAdornment position="end">
              <IconButton
                onClick={() =>
                  setShowPassword(
                    !showPassword
                  )
                }
              >
                {showPassword ? (
                  <VisibilityOff />
                ) : (
                  <Visibility />
                )}
              </IconButton>
            </InputAdornment>
          }
        />
      </FormControl>

      {errors.password && (
        <Typography
          color="error"
          variant="caption"
        >
          {errors.password}
        </Typography>
      )}

      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mt={1}
      >
        <FormControlLabel
          control={
            <Checkbox
              checked={rememberMe}
              onChange={(e) =>
                setRememberMe(
                  e.target.checked
                )
              }
            />
          }
          label="Remember Me"
        />

        <Typography
  color="primary"
  fontWeight={600}
  sx={{
    cursor: "pointer",
  }}
  onClick={() => navigate("/forgot-password")}
>
  Forgot Password?
</Typography>
      </Box>

      <Button
        fullWidth
        variant="contained"
        size="large"
        startIcon={
          !loading && (
            <LoginRoundedIcon />
          )
        }
        onClick={handleLogin}
        disabled={loading}
        sx={{
          mt: 3,
          py: 1.5,
          borderRadius: 3,
          fontSize: 16,
          fontWeight: 700,
          textTransform: "none",
          boxShadow:
            "0 10px 25px rgba(25,118,210,.25)",

          "&:hover": {
            boxShadow:
              "0 12px 30px rgba(25,118,210,.35)",
          },
        }}
      >
        {loading ? (
          <CircularProgress
            size={24}
            color="inherit"
          />
        ) : (
          "Login"
        )}
      </Button>

      <Divider sx={{ my: 4 }} />

      <Typography
        align="center"
        color="text.secondary"
        fontSize={13}
      >
        © 2026 PeopleHub • Human Resource Management System
      </Typography>

    </Box>
  );
}

export default LoginForm;