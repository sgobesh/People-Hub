import {
  Grid,
  TextField,
  MenuItem,
  Typography,
  Box,
} from "@mui/material";

function CandidateForm({
  formData,
  handleChange,
  errors = {},
  jobs = [],
}) {
  return (
    <Grid container spacing={2.5}>

      {/* Personal Information */}

      <Grid size={12}>
        <Typography
          variant="subtitle1"
          fontWeight={700}
          color="primary"
        >
          Personal Information
        </Typography>
      </Grid>

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          fullWidth
          size="small"
          label="First Name"
          name="firstName"
          value={formData.firstName || ""}
          onChange={handleChange}
          error={Boolean(errors.firstName)}
          helperText={errors.firstName}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          fullWidth
          size="small"
          label="Last Name"
          name="lastName"
          value={formData.lastName || ""}
          onChange={handleChange}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          fullWidth
          size="small"
          label="Email Address"
          name="email"
          value={formData.email || ""}
          onChange={handleChange}
          error={Boolean(errors.email)}
          helperText={errors.email}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          fullWidth
          size="small"
          label="Mobile Number"
          name="phone"
          value={formData.phone || ""}
          onChange={(e) => {
            const value = e.target.value.replace(/\D/g, "");

            if (value.length <= 10) {
              handleChange({
                target: {
                  name: "phone",
                  value,
                },
              });
            }
          }}
          error={Boolean(errors.phone)}
          helperText={errors.phone}
          inputProps={{
            maxLength: 10,
          }}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      {/* Professional Information */}

      <Grid size={12}>
        <Box mt={1}>
          <Typography
            variant="subtitle1"
            fontWeight={700}
            color="primary"
          >
            Professional Information
          </Typography>
        </Box>
      </Grid>

      <Grid size={{ xs: 12, md: 4 }}>
        <TextField
          fullWidth
          size="small"
          type="number"
          label="Experience (Years)"
          name="experience"
          value={formData.experience || ""}
          onChange={handleChange}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      <Grid size={{ xs: 12, md: 4 }}>
        <TextField
          fullWidth
          size="small"
          label="Qualification"
          name="qualification"
          value={formData.qualification || ""}
          onChange={handleChange}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      <Grid size={{ xs: 12, md: 4 }}>
        <TextField
          fullWidth
          size="small"
          label="Skills"
          name="skills"
          value={formData.skills || ""}
          onChange={handleChange}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      <Grid size={12}>
        <TextField
          fullWidth
          size="small"
          label="Resume URL"
          name="resumeUrl"
          value={formData.resumeUrl || ""}
          onChange={handleChange}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      {/* Recruitment */}

      <Grid size={12}>
        <Box mt={1}>
          <Typography
            variant="subtitle1"
            fontWeight={700}
            color="primary"
          >
            Recruitment Details
          </Typography>
        </Box>
      </Grid>

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          select
          fullWidth
          size="small"
          label="Applied For Job"
          name="jobId"
          value={formData.jobId || ""}
          onChange={handleChange}
          error={Boolean(errors.jobId)}
          helperText={errors.jobId}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        >
          {jobs.map((job) => (
            <MenuItem key={job.id} value={job.id}>
              {job.jobTitle}
            </MenuItem>
          ))}
        </TextField>
      </Grid>

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          select
          fullWidth
          size="small"
          label="Application Status"
          name="status"
          value={formData.status || "APPLIED"}
          onChange={handleChange}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        >
          <MenuItem value="APPLIED">Applied</MenuItem>
          <MenuItem value="SHORTLISTED">Shortlisted</MenuItem>
          <MenuItem value="SELECTED">Selected</MenuItem>
          <MenuItem value="REJECTED">Rejected</MenuItem>
        </TextField>
      </Grid>

    </Grid>
  );
}

export default CandidateForm;