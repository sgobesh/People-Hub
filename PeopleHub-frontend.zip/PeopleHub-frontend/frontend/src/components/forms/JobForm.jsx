import {
  Grid,
  TextField,
  MenuItem,
  Typography,
  Box,
} from "@mui/material";

function JobForm({
  formData,
  handleChange,
  errors = {},
  readOnly = false,
}) {
  return (
    <Grid container spacing={2.5}>

      {/* Job Information */}

      <Grid size={12}>
        <Typography
          variant="subtitle1"
          fontWeight={700}
          color="primary"
        >
          Job Information
        </Typography>
      </Grid>

      {/* Job Title */}

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          fullWidth
          size="small"
          label="Job Title"
          name="jobTitle"
          value={formData.jobTitle || ""}
          onChange={handleChange}
          error={Boolean(errors.jobTitle)}
          helperText={errors.jobTitle}
          InputProps={{ readOnly }}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      {/* Department */}

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          fullWidth
          size="small"
          label="Department"
          name="department"
          value={formData.department || ""}
          onChange={handleChange}
          error={Boolean(errors.department)}
          helperText={errors.department}
          InputProps={{ readOnly }}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      {/* Location */}

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          fullWidth
          size="small"
          label="Location"
          name="location"
          value={formData.location || ""}
          onChange={handleChange}
          error={Boolean(errors.location)}
          helperText={errors.location}
          InputProps={{ readOnly }}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      {/* Experience */}

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          fullWidth
          size="small"
          type="number"
          label="Experience (Years)"
          name="experience"
          value={formData.experience || ""}
          onChange={handleChange}
          InputProps={{ readOnly }}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      {/* Vacancies */}

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          fullWidth
          size="small"
          type="number"
          label="Vacancies"
          name="vacancies"
          value={formData.vacancies || ""}
          onChange={handleChange}
          error={Boolean(errors.vacancies)}
          helperText={errors.vacancies}
          InputProps={{ readOnly }}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      {/* Salary */}

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          fullWidth
          size="small"
          type="number"
          label="Annual Salary"
          name="salary"
          value={formData.salary || ""}
          onChange={handleChange}
          error={Boolean(errors.salary)}
          helperText={errors.salary}
          InputProps={{ readOnly }}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      {/* Description */}

      <Grid size={12}>
        <Box mt={1}>
          <Typography
            variant="subtitle1"
            fontWeight={700}
            color="primary"
          >
            Job Description
          </Typography>
        </Box>
      </Grid>

      <Grid size={12}>
        <TextField
          fullWidth
          size="small"
          multiline
          rows={5}
          label="Job Description"
          name="description"
          value={formData.description || ""}
          onChange={handleChange}
          error={Boolean(errors.description)}
          helperText={errors.description}
          InputProps={{ readOnly }}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        />
      </Grid>

      {/* Status */}

      <Grid size={12}>
        <Box mt={1}>
          <Typography
            variant="subtitle1"
            fontWeight={700}
            color="primary"
          >
            Recruitment Status
          </Typography>
        </Box>
      </Grid>

      <Grid size={{ xs: 12, md: 6 }}>
        <TextField
          select
          fullWidth
          size="small"
          label="Status"
          name="status"
          value={formData.status || "OPEN"}
          onChange={handleChange}
          InputProps={{ readOnly }}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: 2,
            },
          }}
        >
          <MenuItem value="OPEN">
            Open
          </MenuItem>

          <MenuItem value="CLOSED">
            Closed
          </MenuItem>
        </TextField>
      </Grid>

    </Grid>
  );
}

export default JobForm;