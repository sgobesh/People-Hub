import {
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  IconButton,
  Chip,
  Paper,
  TableContainer,
} from "@mui/material";

import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";

import { useNavigate } from "react-router-dom";

function DepartmentTable({ departments, onDelete }) {
  const navigate = useNavigate();

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell><b>Code</b></TableCell>
            <TableCell><b>Department</b></TableCell>
            <TableCell><b>Head</b></TableCell>
            <TableCell><b>Description</b></TableCell>
            <TableCell align="center"><b>Actions</b></TableCell>
          </TableRow>
        </TableHead>

        <TableBody>
          {departments.map((department) => (
            <TableRow key={department.id}>
              <TableCell>{department.departmentCode}</TableCell>

              <TableCell>
                <Chip
                  label={department.departmentName}
                  color="primary"
                  variant="outlined"
                />
              </TableCell>

              <TableCell>{department.departmentHead}</TableCell>

              <TableCell>{department.description}</TableCell>

              <TableCell align="center">
                <IconButton
                  color="info"
                  onClick={() =>
                    navigate(`/departments/view/${department.id}`)
                  }
                >
                  <VisibilityIcon />
                </IconButton>

                <IconButton
                  color="primary"
                  onClick={() =>
                    navigate(`/departments/edit/${department.id}`)
                  }
                >
                  <EditIcon />
                </IconButton>

                <IconButton
                  color="error"
                  onClick={() => onDelete(department.id)}
                >
                  <DeleteIcon />
                </IconButton>
              </TableCell>
            </TableRow>
          ))}

          {departments.length === 0 && (
            <TableRow>
              <TableCell colSpan={5} align="center">
                No Departments Found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export default DepartmentTable;