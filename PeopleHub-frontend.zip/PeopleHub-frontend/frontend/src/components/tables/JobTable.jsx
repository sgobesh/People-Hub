import {

Chip,
IconButton,
Paper,
Table,
TableBody,
TableCell,
TableContainer,
TableHead,
TableRow

} from "@mui/material";


import VisibilityIcon from "@mui/icons-material/Visibility";

import EditIcon from "@mui/icons-material/Edit";

import DeleteIcon from "@mui/icons-material/Delete";

import LockIcon from "@mui/icons-material/Lock";


import {
useNavigate
} from "react-router-dom";


import jobService from "../../services/jobService";







function JobTable({

jobs,

loadJobs,

onDelete

}){



const navigate=useNavigate();







const closeJob=async(id)=>{


try{


await jobService.closeJob(id);


loadJobs();


}

catch(error){

console.error(error);

}


};









return (


<TableContainer component={Paper}>


<Table>





<TableHead>

<TableRow>


<TableCell>
<b>Job Title</b>
</TableCell>


<TableCell>
<b>Department</b>
</TableCell>


<TableCell>
<b>Location</b>
</TableCell>


<TableCell>
<b>Vacancies</b>
</TableCell>


<TableCell>
<b>Salary</b>
</TableCell>


<TableCell>
<b>Status</b>
</TableCell>


<TableCell align="center">
<b>Actions</b>
</TableCell>


</TableRow>

</TableHead>







<TableBody>



{
jobs.length===0 ?


<TableRow>

<TableCell
colSpan={7}
align="center"
>

No Jobs Found

</TableCell>

</TableRow>



:

jobs.map(job=>(


<TableRow key={job.id}>


<TableCell>
{job.jobTitle}
</TableCell>


<TableCell>
{job.department}
</TableCell>


<TableCell>
{job.location}
</TableCell>


<TableCell>
{job.vacancies}
</TableCell>


<TableCell>

₹ {job.salary?.toLocaleString()}

</TableCell>


<TableCell>

<Chip

label={job.status}

color={
job.status==="OPEN"
?
"success"
:
"error"
}

/>

</TableCell>





<TableCell align="center">





<IconButton

color="info"

onClick={()=>

navigate(
`/jobs/view/${job.id}`
)

}

>

<VisibilityIcon/>

</IconButton>







<IconButton

color="primary"

onClick={()=>

navigate(
`/jobs/edit/${job.id}`
)

}

>

<EditIcon/>

</IconButton>









{
job.status==="OPEN"

&&

<IconButton

color="warning"

onClick={()=>
closeJob(job.id)
}

>

<LockIcon/>

</IconButton>

}









<IconButton

color="error"

onClick={()=>
onDelete(job.id)
}

>

<DeleteIcon/>

</IconButton>







</TableCell>




</TableRow>



))

}




</TableBody>





</Table>


</TableContainer>


);


}


export default JobTable;