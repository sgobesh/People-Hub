import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Button,
} from "@mui/material";

import VisibilityIcon from "@mui/icons-material/Visibility";
import PaymentsIcon from "@mui/icons-material/Payments";

import { useNavigate } from "react-router-dom";

function PayrollTable({ payrolls, onPay }) {
  const navigate = useNavigate();

  const getStatusColor = (status) => {
    switch (status) {
      case "PAID":
        return "success";
      case "GENERATED":
        return "warning";
      default:
        return "default";
    }
  };

  return (
    <TableContainer component={Paper}>
      <Table>

        <TableHead>
          <TableRow>
            <TableCell><b>Employee</b></TableCell>
            <TableCell><b>Month</b></TableCell>
            <TableCell><b>Year</b></TableCell>
            <TableCell><b>Basic Salary</b></TableCell>
            <TableCell><b>Gross Salary</b></TableCell>
            <TableCell><b>Net Salary</b></TableCell>
            <TableCell><b>Status</b></TableCell>
            <TableCell align="center"><b>Actions</b></TableCell>
          </TableRow>
        </TableHead>

        <TableBody>

          {payrolls.map((payroll) => (

            <TableRow key={payroll.id} hover>

              <TableCell>{payroll.employeeName}</TableCell>

              <TableCell>{payroll.month}</TableCell>

              <TableCell>{payroll.year}</TableCell>

              <TableCell>
                ₹ {payroll.basicSalary?.toLocaleString()}
              </TableCell>

              <TableCell>
                ₹ {payroll.grossSalary?.toLocaleString()}
              </TableCell>

              <TableCell>
                ₹ {payroll.netSalary?.toLocaleString()}
              </TableCell>

              <TableCell>
                <Chip
                  label={payroll.status}
                  color={getStatusColor(payroll.status)}
                />
              </TableCell>

              <TableCell align="center">

                <IconButton
                  color="info"
                  onClick={() =>
                    navigate(`/payroll/view/${payroll.id}`)
                  }
                >
                  <VisibilityIcon />
                </IconButton>

                {payroll.status !== "PAID" && (

                  <Button
                    size="small"
                    variant="contained"
                    color="success"
                    startIcon={<PaymentsIcon />}
                    onClick={() => onPay(payroll.id)}
                  >
                    Pay
                  </Button>

                )}

              </TableCell>

            </TableRow>

          ))}

          {payrolls.length === 0 && (

            <TableRow>

              <TableCell
                colSpan={8}
                align="center"
              >
                No Payroll Records Found
              </TableCell>

            </TableRow>

          )}

        </TableBody>

      </Table>
    </TableContainer>
  );
}

export default PayrollTable;