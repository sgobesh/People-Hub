import {
  Card,
  CardContent,
  Chip,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";

import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";

import { useNavigate } from "react-router-dom";

function AttendanceTable({ attendance, onDelete }) {

  const navigate = useNavigate();

  return (
    <Card sx={{ borderRadius: 3 }}>
      <CardContent>

        <Typography variant="h6" mb={2}>
          Attendance List
        </Typography>

        <TableContainer>

          <Table>

            <TableHead>

              <TableRow>

                <TableCell><b>Employee</b></TableCell>

                <TableCell><b>Date</b></TableCell>

                <TableCell><b>Check In</b></TableCell>

                <TableCell><b>Check Out</b></TableCell>

                <TableCell><b>Status</b></TableCell>

                <TableCell align="center"><b>Actions</b></TableCell>

              </TableRow>

            </TableHead>

            <TableBody>

              {attendance.map((item) => (

                <TableRow key={item.id} hover>

                  <TableCell>{item.employeeName}</TableCell>

                  <TableCell>{item.attendanceDate}</TableCell>

                  <TableCell>
                    {item.checkIn?.replace("T", " ")}
                  </TableCell>

                  <TableCell>
                    {item.checkOut
                      ? item.checkOut.replace("T", " ")
                      : "-"}
                  </TableCell>

                  <TableCell>

                    <Chip
                      label={item.status}
                      color={
                        item.status === "PRESENT"
                          ? "success"
                          : item.status === "ABSENT"
                          ? "error"
                          : "warning"
                      }
                    />

                  </TableCell>

                  <TableCell align="center">

                    <IconButton
                      color="primary"
                      onClick={() =>
                        navigate(`/attendance/view/${item.id}`)
                      }
                    >
                      <VisibilityIcon />
                    </IconButton>

                    <IconButton
                      color="warning"
                      onClick={() =>
                        navigate(`/attendance/edit/${item.id}`)
                      }
                    >
                      <EditIcon />
                    </IconButton>

                    <IconButton
                      color="error"
                      onClick={() => onDelete(item.id)}
                    >
                      <DeleteIcon />
                    </IconButton>

                  </TableCell>

                </TableRow>

              ))}

            </TableBody>

          </Table>

        </TableContainer>

      </CardContent>
    </Card>
  );
}

export default AttendanceTable;