import {
  Card,
  CardContent,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Tooltip,
} from "@mui/material";

import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";

import { useNavigate } from "react-router-dom";

import employeeService from "../../services/employeeService";

function EmployeeTable({ employees, onDelete }) {
  const navigate = useNavigate();

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this employee?"
    );

    if (!confirmDelete) return;

    try {
      await employeeService.deleteEmployee(id);

      alert("Employee deleted successfully.");

      // Remove employee from UI
      if (onDelete) {
        onDelete(id);
      }
    } catch (error) {

  console.error(error);

  if (error.response?.data?.message) {
    alert(error.response.data.message);
  } else {
    alert("Unable to delete employee.");
  }

}
  };

  return (
    <Card sx={{ borderRadius: 3 }}>
      <CardContent>
        <Typography variant="h6" mb={2}>
          Employee List
        </Typography>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>
                  <b>Employee ID</b>
                </TableCell>

                <TableCell>
                  <b>Name</b>
                </TableCell>

                <TableCell>
                  <b>Email</b>
                </TableCell>

                <TableCell>
                  <b>Phone</b>
                </TableCell>

                <TableCell>
                  <b>Department</b>
                </TableCell>

                <TableCell>
                  <b>Designation</b>
                </TableCell>

                <TableCell>
                  <b>Salary</b>
                </TableCell>

                <TableCell align="center">
                  <b>Actions</b>
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {employees.length > 0 ? (
                employees.map((emp) => (
                  <TableRow key={emp.id} hover>
                    <TableCell>{emp.employeeId}</TableCell>

                    <TableCell>
                      {emp.firstName} {emp.lastName}
                    </TableCell>

                    <TableCell>{emp.email}</TableCell>

                    <TableCell>{emp.phone}</TableCell>

                    <TableCell>{emp.departmentName}</TableCell>

                    <TableCell>{emp.designation}</TableCell>

                    <TableCell>
                      ₹ {Number(emp.salary).toLocaleString()}
                    </TableCell>

                    <TableCell align="center">
                      <Tooltip title="View Employee">
                        <IconButton
                          color="primary"
                          onClick={() =>
                            navigate(`/employees/view/${emp.id}`)
                          }
                        >
                          <VisibilityIcon />
                        </IconButton>
                      </Tooltip>

                      <Tooltip title="Edit Employee">
                        <IconButton
                          color="warning"
                          onClick={() =>
                            navigate(`/employees/edit/${emp.id}`)
                          }
                        >
                          <EditIcon />
                        </IconButton>
                      </Tooltip>

                      <Tooltip title="Delete Employee">
                        <IconButton
                          color="error"
                          onClick={() => handleDelete(emp.id)}
                        >
                          <DeleteIcon />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={8}
                    align="center"
                  >
                    No Employees Found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </CardContent>
    </Card>
  );
}

export default EmployeeTable; 