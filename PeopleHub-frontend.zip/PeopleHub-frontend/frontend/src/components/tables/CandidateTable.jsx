import {
  Chip,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
} from "@mui/material";

import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";

import { useNavigate } from "react-router-dom";

function CandidateTable({
  candidates,
  page,
  rowsPerPage,
  setPage,
  setRowsPerPage,
  onDelete,
}) {
  const navigate = useNavigate();

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const paginatedCandidates = candidates.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  const getStatusColor = (status) => {
    switch (status) {
      case "SELECTED":
        return "success";
      case "SHORTLISTED":
        return "warning";
      case "REJECTED":
        return "error";
      case "APPLIED":
      default:
        return "info";
    }
  };

  return (
    <>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell><b>Name</b></TableCell>
              <TableCell><b>Email</b></TableCell>
              <TableCell><b>Phone</b></TableCell>
              <TableCell><b>Applied Job</b></TableCell>
              <TableCell><b>Experience</b></TableCell>
              <TableCell><b>Status</b></TableCell>
              <TableCell align="center"><b>Actions</b></TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {paginatedCandidates.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} align="center">
                  No Candidates Found
                </TableCell>
              </TableRow>
            ) : (
              paginatedCandidates.map((candidate) => (
                <TableRow key={candidate.id} hover>
                  <TableCell>
                    {candidate.firstName} {candidate.lastName}
                  </TableCell>

                  <TableCell>{candidate.email}</TableCell>

                  <TableCell>{candidate.phone || "-"}</TableCell>

                  <TableCell>{candidate.jobTitle || "-"}</TableCell>

                  <TableCell>
                    {candidate.experience ?? "-"}
                  </TableCell>

                  <TableCell>
                    <Chip
                      label={candidate.status}
                      color={getStatusColor(candidate.status)}
                      size="small"
                    />
                  </TableCell>

                  <TableCell align="center">
                    <IconButton
                      color="info"
                      onClick={() =>
                        navigate(`/candidates/view/${candidate.id}`)
                      }
                    >
                      <VisibilityIcon />
                    </IconButton>

                    <IconButton
                      color="primary"
                      onClick={() =>
                        navigate(`/candidates/edit/${candidate.id}`)
                      }
                    >
                      <EditIcon />
                    </IconButton>

                    <IconButton
                      color="error"
                      onClick={() => onDelete(candidate.id)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        component="div"
        count={candidates.length}
        page={page}
        rowsPerPage={rowsPerPage}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        rowsPerPageOptions={[5, 10, 25]}
      />
    </>
  );
}

export default CandidateTable;