import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
} from "@mui/material";

import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";

import { useNavigate } from "react-router-dom";

import leaveService from "../../services/leaveService";

function LeaveTable({ leaves, onDelete, loadLeaves }) {
  const navigate = useNavigate();

  const approveLeave = async (id) => {
    try {
      await leaveService.approveLeave(id);
      loadLeaves();
    } catch (error) {
      console.error(error);
    }
  };

  const rejectLeave = async (id) => {
    try {
      await leaveService.rejectLeave(id);
      loadLeaves();
    } catch (error) {
      console.error(error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "Approved":
        return "success";
      case "Rejected":
        return "error";
      default:
        return "warning";
    }
  };

  return (
    <TableContainer component={Paper}>
      <Table>

        <TableHead>
          <TableRow>
            <TableCell><b>Leave Code</b></TableCell>
            <TableCell><b>Employee</b></TableCell>
            <TableCell><b>Type</b></TableCell>
            <TableCell><b>Start Date</b></TableCell>
            <TableCell><b>End Date</b></TableCell>
            <TableCell><b>Days</b></TableCell>
            <TableCell><b>Status</b></TableCell>
            <TableCell><b>Approved By</b></TableCell>
            <TableCell align="center"><b>Actions</b></TableCell>
          </TableRow>
        </TableHead>

        <TableBody>

          {leaves.map((leave) => (

            <TableRow key={leave.id}>

              <TableCell>{leave.leaveCode}</TableCell>

              <TableCell>
                {leave.employee?.firstName} {leave.employee?.lastName}
              </TableCell>

              <TableCell>{leave.leaveType}</TableCell>

              <TableCell>{leave.startDate}</TableCell>

              <TableCell>{leave.endDate}</TableCell>

              <TableCell>{leave.numberOfDays}</TableCell>

              <TableCell>
                <Chip
                  label={leave.status}
                  color={getStatusColor(leave.status)}
                />
              </TableCell>

              <TableCell>
                {leave.approvedBy || "-"}
              </TableCell>

              <TableCell align="center">

                <IconButton
                  color="info"
                  onClick={() => navigate(`/leave/view/${leave.id}`)}
                >
                  <VisibilityIcon />
                </IconButton>

                <IconButton
                  color="primary"
                  onClick={() => navigate(`/leave/edit/${leave.id}`)}
                >
                  <EditIcon />
                </IconButton>

                {leave.status === "Pending" && (
                  <>
                    <IconButton
                      color="success"
                      onClick={() => approveLeave(leave.id)}
                    >
                      <CheckCircleIcon />
                    </IconButton>

                    <IconButton
                      color="warning"
                      onClick={() => rejectLeave(leave.id)}
                    >
                      <CancelIcon />
                    </IconButton>
                  </>
                )}

                <IconButton
                  color="error"
                  onClick={() => onDelete(leave.id)}
                >
                  <DeleteIcon />
                </IconButton>

              </TableCell>

            </TableRow>

          ))}

          {leaves.length === 0 && (
            <TableRow>
              <TableCell colSpan={9} align="center">
                No Leave Records Found
              </TableCell>
            </TableRow>
          )}

        </TableBody>

      </Table>
    </TableContainer>
  );
}

export default LeaveTable;  