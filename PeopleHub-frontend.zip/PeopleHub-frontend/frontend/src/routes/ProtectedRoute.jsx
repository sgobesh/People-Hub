import { Navigate, Outlet } from "react-router-dom";

function ProtectedRoute({ children }) {

  const token = localStorage.getItem("token");

  // No token
  if (!token) {
    return <Navigate to="/" replace />;
  }

  // Check token expiry
  try {

    const payload = JSON.parse(atob(token.split(".")[1]));

    if (payload.exp * 1000 < Date.now()) {

      localStorage.removeItem("token");
      localStorage.removeItem("user");

      return <Navigate to="/" replace />;
    }

  } catch (error) {

    localStorage.removeItem("token");
    localStorage.removeItem("user");

    return <Navigate to="/" replace />;
  }

  return children ? children : <Outlet />;
}

export default ProtectedRoute;