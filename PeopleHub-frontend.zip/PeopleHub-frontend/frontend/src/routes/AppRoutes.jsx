import {
  BrowserRouter,
  Navigate,
  Route,
  Routes,
} from "react-router-dom";


import Login from "../pages/auth/Login";
import ForgotPassword from "../pages/auth/ForgotPassword";

import Dashboard from "../pages/dashboard/Dashboard";


import EmployeeList from "../pages/employee/EmployeeList";
import AddEmployee from "../pages/employee/AddEmployee";
import EditEmployee from "../pages/employee/EditEmployee";
import ViewEmployee from "../pages/employee/ViewEmployee";


import AttendanceList from "../pages/attendance/AttendanceList";
import MarkAttendance from "../pages/attendance/MarkAttendance";
import EditAttendance from "../pages/attendance/EditAttendance";
import ViewAttendance from "../pages/attendance/ViewAttendance";


import DepartmentList from "../pages/department/DepartmentList";
import AddDepartment from "../pages/department/AddDepartment";
import EditDepartment from "../pages/department/EditDepartment";
import ViewDepartment from "../pages/department/ViewDepartment";


import LeaveList from "../pages/leave/LeaveList";
import ApplyLeave from "../pages/leave/ApplyLeave";
import EditLeave from "../pages/leave/EditLeave";
import ViewLeave from "../pages/leave/ViewLeave";


import PayrollList from "../pages/payroll/PayrollList";
import GeneratePayroll from "../pages/payroll/GeneratePayroll";
import ViewPayroll from "../pages/payroll/ViewPayroll";
import PayrollHistory from "../pages/payroll/PayrollHistory";


import RecruitmentDashboard from "../pages/recruitment/RecruitmentDashboard";

import JobList from "../pages/recruitment/JobList";
import AddJob from "../pages/recruitment/AddJob";
import EditJob from "../pages/recruitment/EditJob";
import ViewJob from "../pages/recruitment/ViewJob";


import CandidateList from "../pages/recruitment/CandidateList";
import AddCandidate from "../pages/recruitment/AddCandidate";
import EditCandidate from "../pages/recruitment/EditCandidate";
import ViewCandidate from "../pages/recruitment/ViewCandidate";


import NotificationList from "../pages/notification/NotificationList";

import Settings from "../pages/settings/Settings";


import MainLayout from "../components/layout/MainLayout";

import ProtectedRoute from "./ProtectedRoute";



function AppRoutes() {


  return (

    <BrowserRouter>


      <Routes>



        {/* ============================
            PUBLIC ROUTES
        ============================ */}


        <Route
          path="/"
          element={<Login />}
        />



        <Route
          path="/forgot-password"
          element={<ForgotPassword />}
        />





        {/* ============================
            PROTECTED ROUTES
        ============================ */}


        <Route

          element={

            <ProtectedRoute>

              <MainLayout />

            </ProtectedRoute>

          }

        >




          {/* Dashboard */}

          <Route
            path="/dashboard"
            element={<Dashboard />}
          />





          {/* Employee */}

          <Route
            path="/employees"
            element={<EmployeeList />}
          />


          <Route
            path="/employees/add"
            element={<AddEmployee />}
          />


          <Route
            path="/employees/edit/:id"
            element={<EditEmployee />}
          />


          <Route
            path="/employees/view/:id"
            element={<ViewEmployee />}
          />






          {/* Department */}

          <Route
            path="/departments"
            element={<DepartmentList />}
          />


          <Route
            path="/departments/add"
            element={<AddDepartment />}
          />


          <Route
            path="/departments/edit/:id"
            element={<EditDepartment />}
          />


          <Route
            path="/departments/view/:id"
            element={<ViewDepartment />}
          />







          {/* Attendance */}

          <Route
            path="/attendance"
            element={<AttendanceList />}
          />


          <Route
            path="/attendance/add"
            element={<MarkAttendance />}
          />


          <Route
            path="/attendance/edit/:id"
            element={<EditAttendance />}
          />


          <Route
            path="/attendance/view/:id"
            element={<ViewAttendance />}
          />







          {/* Leave */}

          <Route
            path="/leave"
            element={<LeaveList />}
          />


          <Route
            path="/leave/add"
            element={<ApplyLeave />}
          />


          <Route
            path="/leave/edit/:id"
            element={<EditLeave />}
          />


          <Route
            path="/leave/view/:id"
            element={<ViewLeave />}
          />







          {/* Payroll */}

          <Route
            path="/payroll"
            element={<PayrollList />}
          />


          <Route
            path="/payroll/generate"
            element={<GeneratePayroll />}
          />


          <Route
            path="/payroll/view/:id"
            element={<ViewPayroll />}
          />


          <Route
            path="/payroll/history/:employeeId"
            element={<PayrollHistory />}
          />







          {/* Recruitment */}

          <Route
            path="/recruitment"
            element={<RecruitmentDashboard />}
          />



          <Route
            path="/jobs"
            element={<JobList />}
          />


          <Route
            path="/jobs/add"
            element={<AddJob />}
          />


          <Route
            path="/jobs/edit/:id"
            element={<EditJob />}
          />


          <Route
            path="/jobs/view/:id"
            element={<ViewJob />}
          />





          <Route
            path="/candidates"
            element={<CandidateList />}
          />


          <Route
            path="/candidates/add"
            element={<AddCandidate />}
          />


          <Route
            path="/candidates/edit/:id"
            element={<EditCandidate />}
          />


          <Route
            path="/candidates/view/:id"
            element={<ViewCandidate />}
          />








          {/* Notifications */}

          <Route
            path="/notifications"
            element={<NotificationList />}
          />






          {/* Settings */}

          <Route
            path="/settings"
            element={<Settings />}
          />



        </Route>






        {/* Invalid Route */}

        <Route

          path="*"

          element={

            <Navigate
              to="/"
              replace
            />

          }

        />



      </Routes>


    </BrowserRouter>

  );

}


export default AppRoutes;