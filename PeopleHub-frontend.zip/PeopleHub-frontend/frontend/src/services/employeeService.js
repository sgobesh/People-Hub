import api from "./api";

const employeeService = {
  // Get all employees
  getAllEmployees() {
    return api.get("/employees");
  },

  // Get paginated employees
  getEmployees(page = 0, size = 5) {
    return api.get(`/employees/page?page=${page}&size=${size}`);
  },

  // Get employee by ID
  getEmployeeById(id) {
    return api.get(`/employees/${id}`);
  },

  // Create employee
  createEmployee(employee) {
    return api.post("/employees", employee);
  },

  // Update employee
  updateEmployee(id, employee) {
    return api.put(`/employees/${id}`, employee);
  },

  // Delete employee
  deleteEmployee(id) {
    return api.delete(`/employees/${id}`);
  },

  // Search employees
  searchEmployees(keyword) {
    return api.get(`/employees/search?keyword=${keyword}`);
  },
};

export default employeeService;