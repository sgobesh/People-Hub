import api from "./api";

const jobService = {

  getAllJobs() {
    return api.get("/jobs");
  },

  getJobById(id) {
    return api.get(`/jobs/${id}`);
  },

  createJob(job) {
    return api.post("/jobs", job);
  },

  updateJob(id, job) {
    return api.put(`/jobs/${id}`, job);
  },

  deleteJob(id) {
    return api.delete(`/jobs/${id}`);
  },

  searchJobs(keyword) {
    return api.get(`/jobs/search?keyword=${keyword}`);
  }

};

export default jobService;