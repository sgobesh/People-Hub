import api from "./api";


const authService = {


  login(credentials) {

    return api.post(
      "/auth/login",
      credentials
    );

  },



  register(user) {

    return api.post(
      "/auth/register",
      user
    );

  },



  resetPassword(data) {

    return api.post(
      "/auth/reset-password",
      data
    );

  },


};


export default authService;