import api from "./api";

const getDepartments = (page = 0, size = 5) => {
  return api.get(`/departments?page=${page}&size=${size}`);
};

const getDepartmentById = (id) => {
  return api.get(`/departments/${id}`);
};

const addDepartment = (department) => {
  return api.post("/departments", department);
};

const updateDepartment = (id, department) => {
  return api.put(`/departments/${id}`, department);
};

const deleteDepartment = (id) => {
  return api.delete(`/departments/${id}`);
};

const searchDepartments = (keyword) => {
  return api.get(`/departments/search?keyword=${keyword}`);
};

export default {
  getDepartments,
  getDepartmentById,
  addDepartment,
  updateDepartment,
  deleteDepartment,
  searchDepartments,
};