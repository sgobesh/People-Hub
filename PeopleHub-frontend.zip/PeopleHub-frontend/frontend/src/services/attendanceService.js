import api from "./api";

const attendanceService = {
  getAllAttendance() {
    return api.get("/attendance");
  },

  getAttendanceById(id) {
    return api.get(`/attendance/${id}`);
  },

  createAttendance(data) {
    return api.post("/attendance", data);
  },

  updateAttendance(id, data) {
    return api.put(`/attendance/${id}`, data);
  },

  deleteAttendance(id) {
    return api.delete(`/attendance/${id}`);
  },
};

export default attendanceService;