import api from "./api";

const candidateService = {

  getAllCandidates() {
    return api.get("/candidates");
  },

  getCandidateById(id) {
    return api.get(`/candidates/${id}`);
  },

  createCandidate(candidate) {
    return api.post("/candidates", candidate);
  },

  updateCandidate(id, candidate) {
    return api.put(`/candidates/${id}`, candidate);
  },

  deleteCandidate(id) {
    return api.delete(`/candidates/${id}`);
  },

  searchCandidates(keyword) {
    return api.get(`/candidates/search?keyword=${keyword}`);
  }

};

export default candidateService;