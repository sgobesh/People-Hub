import api from "./api";

const profileService = {

  getProfile() {
    return api.get("/profile");
  },

  updateProfile(data) {
    return api.put("/profile", data);
  },

  changePassword(data) {
    return api.put("/profile/change-password", data);
  }

};

export default profileService;  