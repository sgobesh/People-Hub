import api from "./api";

const payrollService = {

  generatePayroll(data) {
    return api.post("/payroll", data);
  },

  getAllPayrolls() {
    return api.get("/payroll");
  },

  getPayrollByEmployee(employeeId) {
    return api.get(`/payroll/employee/${employeeId}`);
  },
getPayrollById(id) {
  return api.get(`/payroll/${id}`);
},
  paySalary(id) {
    return api.put(`/payroll/${id}/pay`);
  }

};

export default payrollService;