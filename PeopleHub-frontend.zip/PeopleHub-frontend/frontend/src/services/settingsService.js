import axios from "axios";

const API_URL = "http://localhost:8080/api/settings/company";

const getAuthHeader = () => {
  const token = localStorage.getItem("token");

  return {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };
};

const settingsService = {

  getCompany() {
    return axios.get(
      API_URL,
      getAuthHeader()
    );
  },

  saveCompany(data) {
    return axios.put(
      API_URL,
      data,
      getAuthHeader()
    );
  }

};

export default settingsService;