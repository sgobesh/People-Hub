import api from "./api";

const getLeaves = (page = 0, size = 5) =>
  api.get(`/leaves?page=${page}&size=${size}`);

const getLeaveById = (id) =>
  api.get(`/leaves/${id}`);

const addLeave = (leave) =>
  api.post("/leaves", leave);

const updateLeave = (id, leave) =>
  api.put(`/leaves/${id}`, leave);

const deleteLeave = (id) =>
  api.delete(`/leaves/${id}`);

const searchLeaves = (keyword) =>
  api.get(`/leaves/search?keyword=${keyword}`);

const approveLeave = (id) =>
  api.put(`/leaves/${id}/approve`);

const rejectLeave = (id) =>
  api.put(`/leaves/${id}/reject`);

export default {
  getLeaves,
  getLeaveById,
  addLeave,
  updateLeave,
  deleteLeave,
  searchLeaves,
  approveLeave,
  rejectLeave,
};