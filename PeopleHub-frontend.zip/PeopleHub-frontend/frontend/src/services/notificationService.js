import api from "./api";

const notificationService = {

  getAllNotifications() {
    return api.get("/notifications");
  },

  getNotificationById(id) {
    return api.get(`/notifications/${id}`);
  },

  getUnreadCount() {
    return api.get("/notifications/unread-count");
  },

  markAsRead(id) {
    return api.put(`/notifications/read/${id}`);
  },

  deleteNotification(id) {
    return api.delete(`/notifications/${id}`);
  },

  clearAllNotifications() {
    return api.delete("/notifications/clear");
  }

};

export default notificationService;