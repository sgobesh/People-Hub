import api from "./api";

const getDashboardStats = () => {
  return api.get("/dashboard");
};

export default {
  getDashboardStats,
};